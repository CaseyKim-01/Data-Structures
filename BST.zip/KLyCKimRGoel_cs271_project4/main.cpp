#include<iostream>

#include "bst.cpp"
#include "usecase.cpp"

int main() {
    string bin;
    BST<string, string>* bst = create_bst<string, string>("binhex.txt");

    cout << "Enter binary representation for conversion: " << endl;
    cin >> bin;
    cout << "Hexidecimal representation of " << bin << " is " << convert<string, string>(bst, bin) << endl;

    return 0;
}