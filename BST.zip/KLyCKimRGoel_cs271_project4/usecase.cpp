# include <iostream> 
# include <fstream>
# include <string> 
# include <sstream> 
# include <vector>

#include "bst.h"

using namespace std;

/**
 * Creates and returns a BST object generated from hex-binary key-value pairs in the
 * given CSV file.
 *
 * Precondition: 'fname' is the name of a valid CSV file.
 * Postcondition: returns a BST object generated from key value pairs in the given CSV file
 */
template <typename D, typename K>
BST<D, K>* create_bst(string fname) {
    BST<D, K>* bst = new BST<D, K>();

    // CSV File Reading
    vector<vector<string>> info;
    vector<string> each_row;
    string line, word;

    fstream file(fname, ios::in);
    if (file.is_open()) {
        while (getline(file, line))
        {
            stringstream str(line);

            while (getline(str, word, ','))
                each_row.push_back(word);

            info.push_back(each_row);
            each_row.clear();
        }
    }
    else {
        cout << "Could not open the file\n";
    }

    for (int i = 0; i < info.size(); i++) {
        bst->insert(info[i][0], info[i][1]); // key: binary, data: hex
    }

    return bst;
}

/**
 * Converts a given binary string to the corresponding hexadecimal representation
 * based on the values in the binary search tree `bst`.
 *
 * Preconditions: `bst` is a valid BST object and `bin` is a valid binary string.
 * Postconditions: returns the hexadecimal representation of `bin` based on the values in `bst`.
 */
template <typename D, typename K>
string convert(BST<D, K>* bst, string bin) {
    string hex = "";

    if (bin.size() % 4 != 0) {
        string padding(4 - bin.size() % 4, '0');
        bin = padding + bin;
    }

    for (int i = 0; i < bin.size(); i += 4) {
        hex = hex + bst->get(bin.substr(i, 4));
    }

    return hex;
}