#include "bst.h"
#include "bst.cpp"

void test_empty() { 
    try
    {
        //Test case 1
        BST<string, int> bst;
        if(!bst.empty()) {
            cout << "Incorrect empty result." << endl;
        }

        //Test case 2
        bst.insert("one",1);
        if(bst.empty()) {
            cout << "Incorrect empty result." << endl;
        }

        //Test case 3
        bst.insert("two", 2);
        bst.insert("three", 3);
        bst.insert("four", 4);
        if(bst.empty()) {
            cout << "Incorrect empty result." << endl;
        }

        //Test case 4
        BST<double, char> bst2;
        if(!bst2.empty()) {
            cout << "Incorrect empty result." << endl;
        }

        //Test case 5 
        bst2.insert(0.14, 'a');
        bst2.insert(3.89, 'z');
        if(bst2.empty()) {
            cout << "Incorrect empty result." << endl;
        }

        //Test case 6 
        bst2.remove('z');
        bst2.remove('a');
        if(!bst2.empty()) {
            cout << "Incorrect empty result." << endl;
        }
    }
    catch(exception& e)
    {
        cerr << "Error in determining if BST is empty : " << e.what() << endl;
    }
}


void test_insert() {
    try {
        //Test case 1
        BST<string, int> bst;
        bst.insert("one", 1);
        string bst_str = bst.to_string();
        if(bst_str != "1") {
            cout << "Incorrect result of inserting (\"one\", 1). Expected 1 but got : " << bst_str << endl;
        }

        //Test case 2
        bst.insert("another one", 1); 
        bst_str = bst.to_string();
        if(bst_str != "1") {
            cout << "Incorrect result of inserting (\"another one\", 1). Expected 1 but got : " << bst_str << endl;
        }

        //Test case 3 
        BST<string, int> bst1;
        for(int i = 1; i <= 10; i++) {
            bst1.insert("some data", i);
        }
        string bst1_str = bst1.to_string();
        if(bst1_str != "1 2 3 4 5 6 7 8 9 10") {
            cout << "Incorrect result of inserting keys 1-10 in order. Expected 1 2 3 4 5 6 7 8 9 10 but got : " << bst1_str << endl;
        }

        //Test case 4
        int vals[10] = {5, 2, 7, 1, 3, 4, 6, 9, 8, 10};
        BST<string, int> balanced_bst;
        for(int i = 0; i < 10; i++) {
            balanced_bst.insert("some data", vals[i]);
        }
        bst_str = balanced_bst.to_string();
        if(bst_str != "5 2 7 1 3 6 9 4 8 10") {
            cout << "Incorrect result of inserting keys {5, 2, 7, 1, 3, 4, 6, 9, 8, 10}. Expected 5 2 7 1 3 6 9 4 8 10 but got : " << bst_str << endl;
        }

        //Test case 5
        BST<char, int> bst2;
        for(int i = 10; i > 0; i--) {
            bst2.insert('?', i);
        }
        string bst2_str = bst2.to_string();
        if(bst2_str != "10 9 8 7 6 5 4 3 2 1") {
            cout << "Incorrect result of inserting keys {10, 9, 8, 7, 6, 5, 4, 3, 2, 1}. Expected 10 9 8 7 6 5 4 3 2 1 but got : " << bst2_str << endl;
        }

        //Test case 6
        BST<bool, string> bst3;
        string keys[8] = {"James", "Luke", "Casey", "Krystal", "Raghav", "Ally", "Bryan", "Blaire"};
        for(int i = 0; i < 8; i++) {
            bst3.insert(true, keys[i]);
        }
        string bst3_str = bst3.to_string();
        if(bst3_str != "James Casey Luke Ally Krystal Raghav Bryan Blaire") {
            cout << "Incorrect result of inserting keys {\"James\", \"Luke\", \"Casey\", \"Krystal\", \"Raghav\", \"Ally\", \"Bryan\", \"Blaire\"}. Expected James Casey Luke Ally Krystal Raghav Bryan Blaire but got :" << bst3_str << endl;
        }
        
    } catch(exception& e) {
        cerr << "Error inserting into bst : " << e.what() << endl;
    }
}

void test_get() {
    try {
        //Test case 1 
        BST<string, int> bst;
        string val = bst.get(4);
        if(val!="") {
            cout << "Incorrect get result from empty bst. Expected an empty string but got " << val << endl;
        }

        //Test case 2
        bst.insert("one",1);
        val = bst.get(1);
        if(val != "one") {
            cout << "Incorrect get result. Expected \"one\" but got : " << val << endl;
        }

        //Test case 3
        val = bst.get(3);
        if(val != "") {
            cout << "Incorrect get result. Expected an empty string but got : " << val << endl;
        }

        //Test case 4 
        BST<int, char> bst2;
        char keys[5] = {'a', 'b', 'c', 'd', 'e'};
        for (int i = 0; i < 5; i++) {
            bst2.insert(i * 10, keys[i]);
        }
        float val_f = bst2.get('c');
        if(val_f != 20) {
            cout << "Incorrect get result. Expected 20 but got : " << val_f << endl;
        }
        bst2.insert(20, 'd');
        val_f = bst2.get('d');
        if(val_f != 30) {
            cout << "Incorrect get result. Expected 30 but  got : " << val_f << endl;
        }

        //Test case 5 
        val_f = bst2.get('z');
        if(val_f != 0) {
            cout << "Incorrect get result. Expected 0 but got : " << val_f << endl;
        }

        //Test case 6
        BST<bool, string> bst3;
        string keys_s[8] = {"James", "Luke", "Casey", "Krystal", "Raghav", "Ally", "Bryan", "Blaire"};
        for(int i = 0; i < 8; i++) {
            bst3.insert(true, keys_s[i]);
        }
        bool val_bo = bst3.get("Casey");
        if(val_bo != 1) {
            cout << "Incorrect get result. Expected 1 but got : " << val_bo << endl;
        }
        
    } catch(exception& e) {
        cerr << "Error in getting data from bst : " << e.what() << endl;
    }
}

void test_remove() {
    try {
        int vals[10] = {5, 2, 7, 1, 3, 4, 6, 9, 8, 10};
        BST<string, int> balanced_bst;
        for(int i = 0; i < 10; i++) {
            balanced_bst.insert("some data", vals[i]);
        }

        //Test case 1
        balanced_bst.remove(7);
        string bst_str = balanced_bst.to_string();
        if(bst_str != "5 2 8 1 3 6 9 4 10") {
            cout << "Incorrect result of removing 7. Expected 5 2 8 1 3 6 9 4 10 but got : " << bst_str << endl;
        }

        //Test case 2
        balanced_bst.remove(1);
        bst_str = balanced_bst.to_string();
        if(bst_str != "5 2 8 3 6 9 4 10") {
            cout << "Incorrect result of removing 1. Expected 5 2 8 3 6 9 4 10 but got : " << bst_str << endl;
        }

        //Test case 3
        balanced_bst.remove(5);
        bst_str = balanced_bst.to_string();
        if(bst_str != "6 2 8 3 9 4 10") {
            cout << "Incorrect result of removing 5. Expected 6 2 8 3 9 4 10 but got : " << bst_str << endl;
        }

        //Test case 4
        balanced_bst.remove(3);
        bst_str = balanced_bst.to_string();
        if(bst_str != "6 2 8 4 9 10") {
            cout << "Incorrect result of removing 3. Expected 6 2 8 4 9 10 but got : " << bst_str << endl;
        }

        //Test case 5
        balanced_bst.remove(9);
        balanced_bst.remove(4);
        balanced_bst.remove(8);
        balanced_bst.remove(10);
        balanced_bst.remove(2);
        balanced_bst.remove(6);
        bst_str = balanced_bst.to_string();
        if(bst_str != "") {
            cout << "Incorrect result of removing all nodes. Expected an empty string but got : " << bst_str << endl;
        }

    } catch(exception& e) {
        cerr << "Error in removing node from bst : " << e.what() << endl;
    }
}

void test_max_data() {
    try {
        //Test case 1
        BST<int, double> empty_bst;
        int max_int = empty_bst.max_data();
        if(max_int != 0) {
            cout << "Incorrect result of max_data. Expected 0 but got : " << max_int << endl;
        }

        //Test case 2
        empty_bst.insert(7, 7.7);
        max_int = empty_bst.max_data();
        if(max_int != 7) {
            cout << "Incorrect result of max_data. Expected 7 but got : " << max_int << endl;
        }

        //Test case 3
        int vals[10] = {5, 2, 7, 1, 3, 4, 6, 9, 8, 10};
        BST<string, int> balanced_bst;
        for(int i = 0; i < 10; i++) {
            balanced_bst.insert(to_string(vals[i]) + " data", vals[i]);
        }
        string max_str = balanced_bst.max_data();
        if(max_str != "10 data") {
            cout << "Incorrect result of max_data. Expected \"10 data\" but got : "
<< max_str << endl;
        }

        //Test case 4
        BST<char, int> bst2;
        bst2.insert('e', 1);
        bst2.insert('d', 2);
        bst2.insert('c', 0);
        bst2.insert('b', 4);
        bst2.insert('a', 3);
        char max_char = bst2.max_data();
        if(max_char != 'b') {
            cout << "Incorrect result of max_data. Expected 'b' but got : " << max_char << endl;
        }

        //Test case 5
        bst2.remove(4);
        max_char = bst2.max_data();
        if(max_char != 'a') {
            cout << "Incorrect result of max_data. Expected 'a' but got : " << max_char << endl;
        }

        //Test case 6 
        BST<bool, string> bst3;
        string keys_s[8] = {"James", "Luke", "Casey", "Krystal", "Raghav", "Ally", "Bryan", "Blaire"};
        for(int i = 0; i < 8; i++) {
            bst3.insert(true, keys_s[i]);
        }
        bool max_bool = bst3.max_data();
        if(max_bool != 1) {
            cout << "Incorrect result of max_data. Expected 1 but got : " << max_bool << endl;
        }

    } catch(exception& e) {
        cerr << "Error in determining data of max node in bst : " << e.what() << endl;
    }
}

void test_max_key() {
    try {
        //Test case 1
        BST<int, double> empty_bst;
        double max_double = empty_bst.max_key();
        if(max_double != 0) {
            cout << "Incorrect result of max_key. Expected 0 but got : " << max_double << endl;
        }

        //Test case 2
        empty_bst.insert(7, 7.7);
        max_double = empty_bst.max_key();
        if(max_double != 7.7) {
            cout << "Incorrect result of max_data. Expected 7.7 but got : " << max_double << endl;
        }

        //Test case 3
        int vals[10] = {5, 2, 7, 1, 3, 4, 6, 9, 8, 10};
        BST<string, int> balanced_bst;
        for(int i = 0; i < 10; i++) {
            balanced_bst.insert(to_string(vals[i]) + " data", vals[i]);
        }
        int max_k = balanced_bst.max_key();
        if(max_k != 10) {
            cout << "Incorrect result of max_key. Expected 10 but got : " << max_k 
<< endl;
        }
        
        //Test case 4 
        BST<char, int> bst2;
        bst2.insert('e', 1);
        bst2.insert('d', 2);
        bst2.insert('c', 0);
        bst2.insert('b', 4);
        bst2.insert('a', 3);
        max_k = bst2.max_key();
        if(max_k != 4) {
            cout << "Incorrect result of max_key. Expected 4 but got : " << max_k << endl;
        }

        //Test case 5
        bst2.remove(4);
        max_k = bst2.max_key();
        if(max_k != 3) {
            cout << "Incorrect result of max_key. Expected 3 but got : " << max_k << endl;
        }

        //Test case 6 
        BST<bool, string> bst3;
        string keys_s[8] = {"James", "Luke", "Casey", "Krystal", "Raghav", "Ally", "Bryan", "Blaire"};
        for(int i = 0; i < 8; i++) {
            bst3.insert(true, keys_s[i]);
        }
        string max_kstr = bst3.max_key();
        if(max_kstr != "Raghav") {
            cout << "Incorrect result of max_key. Expected Raghav but got : " << max_kstr << endl;
        }

    } catch(exception& e) {
        cerr << "Error in determining key of max node in bst : " << e.what() << endl;
    }
}

void test_min_data() {
    try {

        //Test case 1
        BST<string, int> balanced_bst;
        string min_str = balanced_bst.min_data();
        if(min_str != "") {
            cout << "Incorrect result of min_data. Expected an empty string but got : " << min_str << endl;
        }

        //Test case 2
        int vals[10] = {5, 2, 7, 1, 3, 4, 6, 9, 8, 10};
        for(int i = 0; i < 10; i++) {
            balanced_bst.insert(to_string(vals[i]) + " data", vals[i]);
        }        
        min_str = balanced_bst.min_data();
        if(min_str != "1 data") {
            cout << "Incorrect result of min_data. Expected \"1 data\" but got : " << min_str << endl;
        }

        //Test case 3
        balanced_bst.remove(2);
        min_str = balanced_bst.min_data();
        if(min_str != "1 data") {
            cout << "Incorrect result of min_data. Expected \"1 data\" but got : " << min_str << endl;
        }

        //Test case 4
        balanced_bst.remove(1);
        min_str = balanced_bst.min_data();
        if(min_str != "3 data") {
            cout << "Incorrect result of min_data. Expected \"3 data\" but got : " << min_str << endl;
        }

        //Test case 5
        BST<string, string> char_bst;
        string chars[8] = {"h","d","c","w","e","x","y","z"};
        for(int i = 0; i < 8; i++) {
            char_bst.insert(chars[i] + " data", chars[i]);
        }
        min_str = char_bst.min_data();
        if(min_str != "c data") {
            cout << "Incorrect result of min_data. Expected \"c data\" but got : " << min_str << endl;
        }     
        
        //Test case 6
        char_bst.remove("c");
        min_str = char_bst.min_data();
        if(min_str != "d data") {
            cout << "Incorrect result of min_data. Expected \"d data\" but got : " << min_str << endl;
        } 

    } catch(exception& e) {
        cerr << "Error in determining data of min node in bst : " << e.what() << endl;
    }
}
void test_min_key() {
    try {
        //Test case 1
        BST<string, int> balanced_bst;
        int min_int = balanced_bst.min_key();
        if(min_int != 0) {
            cout << "Incorrect result of min_data. Expected 0 but got : " << min_int << endl;
        }

        //Test case 2
        int vals[10] = {5, 2, 7, 1, 3, 4, 6, 9, 8, 10};
        for(int i = 0; i < 10; i++) {
            balanced_bst.insert(to_string(vals[i]) + " data", vals[i]);
        }        
        min_int = balanced_bst.min_key();
        if(min_int != 1) {
            cout << "Incorrect result of min_data. Expected 1 but got : " << min_int << endl;
        }

        // //Test case 3
        balanced_bst.remove(2);
        min_int = balanced_bst.min_key();
        if(min_int != 1) {
            cout << "Incorrect result of min_data. Expected 1 but got : " << min_int << endl;
        }

        //Test case 4
        balanced_bst.remove(1);
        min_int = balanced_bst.min_key();
        if(min_int != 3) {
            cout << "Incorrect result of min_data. Expected 3 but got : " << min_int << endl;
        }

        //Test case 5
        BST<string, string> char_bst;
        string chars[8] = {"h","d","c","w","e","x","y","z"};
        for(int i = 0; i < 8; i++) {
            char_bst.insert(chars[i] + " data", chars[i]);
        }
        string min_str = char_bst.min_key();
        if(min_str != "c") {
            cout << "Incorrect result of min_data. Expected c but got : " << min_str << endl;
        }     
        
        //Test case 6
        char_bst.remove("c");
        min_str = char_bst.min_key();
        if(min_str != "d") {
            cout << "Incorrect result of min_data. Expected d but got : " << min_str << endl;
        } 
    } catch(exception& e) {
        cerr << "Error in determining key of min node in bst : " << e.what() << endl;
    }
}


void test_successor() {
    try {
        int vals[10] = {5, 2, 7, 1, 3, 4, 6, 9, 8, 10};
        BST<string, int> balanced_bst;
        for(int i = 0; i < 10; i++) {
            balanced_bst.insert(to_string(vals[i]) + " data", vals[i]);
        }

        //Test case 1
        int succ = balanced_bst.successor(4);
        if(succ != 5) {
            cout << "Incorrect result of successor of 4. Expected 5 but got : " << succ << endl;
        }

        //Test case 2
        succ = balanced_bst.successor(7);
        if(succ != 8) {
            cout << "Incorrect result of successor of 7. Expected 8 but got : " << succ << endl;
        }

        //Test case 3
        succ = balanced_bst.successor(10);
        if(succ != 0) {
            cout << "Incorrect result of successor of 10. Expected 0 but got : " <<succ << endl;
        }
        
        //Test case 4
        succ = balanced_bst.successor(5);
        if(succ != 6) {
            cout << "Incorrect result of successor of 5. Expected 6 but got : " <<succ << endl;
        }

        //Test case 5
        succ = balanced_bst.successor(14);
        if(succ != 0) {
            cout << "Incorrect result of successor of 14. Expected 0 but got : " <<succ << endl;
        }
        
    } catch(exception& e) {
        cerr << "Error in determining successor in bst : " << e.what() << endl;
    }
}

void test_in_order() {
    try {
        //Test case 1
        BST<string, int> bst;
        for(int i = 1; i <= 10; i++) {
            bst.insert("some data", i);
        }
        string bst_str = bst.in_order();
        if(bst_str != "1 2 3 4 5 6 7 8 9 10") {
            cout << "Incorrect in_order result after inserting keys 1-10 in order. Expected 1 2 3 4 5 6 7 8 9 10 but got : " << bst_str << endl;
        }

        //Test case 2
        int vals[10] = {5, 2, 7, 1, 3, 4, 6, 9, 8, 10};
        BST<string, int> balanced_bst;
        for(int i = 0; i < 10; i++) {
            balanced_bst.insert("some data", vals[i]);
        }
        bst_str = balanced_bst.in_order();
        if(bst_str != "1 2 3 4 5 6 7 8 9 10") {
            cout << "Incorrect in_order result after inserting keys {5, 2, 7, 1, 3, 4, 6, 9, 8, 10}. Expected 1 2 3 4 5 6 7 8 9 10 but got : " << bst_str << endl;
        }

        //Test case 3
        BST<double, string> bst2;
        bst2.insert(271, "CS");
        bst2.insert(181, "DA");
        bst2.insert(371, "ECON");
        bst2.insert(200, "BIO");
        bst2.insert(111, "MATH");
        bst_str = bst2.in_order();
        if(bst_str != "BIO CS DA ECON MATH") {
            cout << "Incorrect in_order result after inserting keys {\"CS\", \"DA\", \"ECON\", \"BIO\", \"MATH\"}. Expected BIO CS DA ECON MATH but got : " << bst_str << endl;
        }

    } catch(exception& e) {
        cerr << "Error getting keys in_order from bst : " << e.what() << endl;
    }
}

void test_trim() {
    try {
        //Test case 1
        BST<string,int> bst;
        int vals[3] = {1, 0, 2};
        for(int i = 0; i < 3; i++) {
            bst.insert(to_string(vals[i])+" data", vals[i]);
        }
        bst.trim(1,2);
        string bst_str = bst.to_string();
        if(bst_str != "1 2") {
            cout << "Incorrect tree after trimming 1 0 2 with low=1, high=2. Expected 1 2 but got : " << bst_str << endl;
        }

        //Test case 2
        BST<string, int> bst2;
        int vals2[5] = {3, 0, 4, 2, 1};
        for(int i = 0; i < 5; i++) {
            bst2.insert(to_string(vals2[i])+" data", vals2[i]);
        }
        bst2.trim(1,3);
        bst_str = bst2.to_string();
        if(bst_str != "3 2 1") {
            cout << "Incorrect tree after trimming 3 0 4 2 1 with low=1, high=3. Expected 3 2 1 but got : " << bst_str << endl;
        }

        //Test case 3
        bst2.trim(12,56);
        bst_str = bst2.to_string();
        if(bst_str != "") {
            cout << "Incorrect tree after trimming 3 2 1 with low=12, high=56. Expected an empty string but got : " << bst_str << endl;
        }

        //Test case 4
        BST<string, int> bst3;
        int vals3[7] = {5, 2, 7, 1, 3, 13, 19};
        for(int i = 0; i < 7; i++) {
            bst3.insert(to_string(vals3[i])+" data", vals3[i]);
        }
        bst3.trim(56,12);
        bst_str = bst3.to_string();
        if(bst_str != "5 2 7 1 3 13 19") {
            cout << "Incorrect tree after trimming 5 2 7 1 3 13 19 with low=56, high=12. Expected 5 2 7 1 3 13 19 but got : " << bst_str << endl;
        }

        //Test case 5
        bst3.trim(7,7);
        bst_str = bst3.to_string();
        if(bst_str != "7") {
            cout << "Incorrect tree after trimming 5 2 7 1 3 13 19 with low=7, high=7. Expected 7 but got : " << bst_str << endl;
        }

        //Test case 6
        BST<string, int> bst4;
        int vals4[7] = {5, 2, 7, 1, 3, 13, 19};
        for(int i = 0; i < 7; i++) {
            bst4.insert(to_string(vals4[i])+" data", vals4[i]);
        }
        bst4.trim(2,3);
        bst_str = bst4.to_string();
        if(bst_str != "2 3") {
            cout << "Incorrect tree after trimming 5 2 7 1 3 13 19 with low=2, high=3. Expected 2 3 but got : " << bst_str << endl;
        }

        //Test case 7
        bst4.remove(2);
        bst4.remove(3);
        bst4.trim(2,3);
        bst_str = bst4.to_string();
        if(bst_str != "") {
            cout << "Incorrect tree after trimming an empty bst with low=2, high=3. Expected an empty string but got : " << bst_str << endl;
        }

    } catch(exception& e) {
        cerr << "Error in trimming the bst : " << e.what() << endl;
    }
}


int main()
{
    test_empty();
    test_insert();
    test_get();
    test_remove();
    test_max_data();
    test_max_key();
    test_min_data();
    test_min_key();
    test_successor();
    test_in_order();
    test_trim();
    cout << "Testing Completed" << endl;

    return 0;
}
