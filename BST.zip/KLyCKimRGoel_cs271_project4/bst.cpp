# include "bst.h"

// Constructor
template<typename DataType, typename KeyType> 
BST<DataType, KeyType>::BST() 
{
    root = nullptr;
}

// to_string 
template<typename DataType, typename KeyType>
string BST<DataType, KeyType>::to_string()
{
    // if the tree is empty, return an empty string 
    if (this->empty())
        return "";
    stringstream ss;

    // Traverse the tree level by level (left to right) using a queue
    queue<TreeNode*> q;
    q.push(root);
    while (!q.empty())
    {
        int n = q.size();
        // Traverse nodes in each level and insert the key of each node into the string stream
        for (int i = 0; i < n; i++) {
            TreeNode* node = q.front();
            q.pop();
            ss << node->key << ' ';
            // Insert the children(one level below) of the node into the queue 
            if (node->left)
                q.push(node->left);
            if (node->right)
                q.push(node->right);
        }
    }    
    
    // Convert the string stream into string and remove the unnecessary space
    string ss_str = ss.str();
    ss_str.pop_back();

    return ss_str;
}

// empty
template<typename DataType, typename KeyType> 
bool BST<DataType, KeyType>::empty()
{
    return (root == nullptr);
}

// insert 
template<typename DataType, typename KeyType> 
void BST<DataType, KeyType>::insert(DataType d, KeyType k)
{
    // If the inserting key is not distinct, return 
    if (search(this->root, k) != nullptr)
        return;
    
    // Create a new node with the given key and data 
    TreeNode* newNode = new TreeNode(d, k);
    TreeNode* y = nullptr; 
    TreeNode* x = this->root;

    // Find the correct location to insert the new node 
    while (x != nullptr)
    {
        y = x;
        if (newNode->key < y->key)
            x = x->left;
        else
            x = x->right;
    }

    // Set the parent pointer of the new node 
    newNode->p = y;
    // Check whether the new node should be the left child or the right child of its parent
    if (y == nullptr)
        this->root = newNode;
    else if (newNode->key < y->key)
        y->left = newNode;
    else
        y->right = newNode;
}

// search
template<typename DataType, typename KeyType>
typename BST<DataType, KeyType>::TreeNode* BST<DataType, KeyType>::search(TreeNode* x, KeyType k)
{
    // If the tree is empty or there is no node with the target key, return NIL
    if (x == nullptr)
        return nullptr;
    
    // If the target key is found, return the node with that key 
    if (x->key == k)
        return x;
    // If the target key is smaller than the root, search the left portion of the tree
    if (k < x->key)
        return search(x->left, k);
    // If the target key is bigger than the root, search the right portion of the tree
    else
        return search(x->right, k);
}

// transplant
template<typename DataType, typename KeyType> 
void BST<DataType, KeyType>::transplant(typename BST<DataType, KeyType>::TreeNode* u, typename BST<DataType, KeyType>::TreeNode* v)
{
    // If u is the root, replace the root with v
    if (u->p == nullptr) {
        root = v;
    }
    // If u is the left subtree of its parent, replace it with v 
    else if (u->p->left == u) {
        u->p->left = v;
    }
    // If u is the right subtree of its parent, replace it with v 
    else {
        u->p->right = v;
    }
    // Link v to its parent 
    if (v != nullptr)
        v->p = u->p;
}

// remove
template<typename DataType, typename KeyType> 
void BST<DataType, KeyType>::remove(KeyType k) 
{
    // If the node with key k does not exist in the tree, return 
    TreeNode* z = search(this->root, k);
    if (z == nullptr)
        return;

    // Case 1: when z has no child
    if (z->left == nullptr and z->right == nullptr) {
        //when z has no child and z is the root node
        if (z->p == nullptr) {
            root = nullptr;
        }
        //when z has no child and z is the left child of its parent
        else if (z->p->left == z) {
            
            z->p->left = nullptr;
        }
        //when z has no child and z is the right child of its parent
        else if (z->p->right == z) {
            z->p->right = nullptr;
        }
    }
    // Case 2: when z only has a right child, replace z with its right child 
    else if (z->left == nullptr) {
        transplant(z, z->right);
    }
    // Case 3: when z only has a left child, replace z with its left child
    else if (z->right == nullptr) {
        transplant(z, z->left);
    }
    // Case 4: when z has both children, find the successor of z
    else 
    {
        TreeNode* y = successor_node(z->key);
        //if y is not z's right child, replace y with y's right child
        if (y->p != z)
        {
            // when y have a right child
            if (y->right != nullptr) {        
                transplant(y, y->right);
            }
            // when y doesn't have a right child, replace y with a null pointer
            else {
                y->p->left = nullptr;
            }
            //make z's right child to be y's right child
            y->right = z->right;
            y->right->p = y;
        }
        // Replace z with y 
        transplant(z, y);
        y->left = z->left;
        y->left->p = y;
    }
    delete z; 
}

// get 
template<typename DataType, typename KeyType>
DataType BST<DataType, KeyType>::get(KeyType k)
{   
    // If the tree is empty, return a default element 
    if (this->empty())
        return DataType();
    
    // Get the node with key k 
    TreeNode* x = search(root, k);

    // If there is no node with key k, return a default element 
    if (x == nullptr)
        return DataType();
    // Otherwise, return the data associated with that node 
    return x->data;
}

// max_data
template<typename DataType, typename KeyType>
DataType BST<DataType, KeyType>::max_data(){

    // If the tree is not empty 
    if (root != nullptr){
        // Follow the right child pointer until it finds the rightmost node of the tree
        TreeNode* x = root;
        while (x->right != nullptr){
            x = x->right;
        }
        // Return the data associated with the rightmost node 
        return x->data;
    }
    // If the tree is empty, return a default element 
    else {
        return DataType();
    }
}

// max_key
template<typename DataType, typename KeyType>
KeyType BST<DataType, KeyType>::max_key(){

    // If the tree is not empty
    if (root != nullptr){
        // Follow the right child pointer until it finds the rightmost node of the tree
        TreeNode* x = root;
        while (x->right != nullptr){
            x = x->right;
        }
        // Return the key associated with the rightmost node 
        return x->key;
    }
    // If the tree is empty, return a default element 
    else {
        return KeyType();         
    }
}

// min_data
template<typename DataType, typename KeyType>
DataType BST<DataType, KeyType>::min_data(){

    // If the tree is not empty 
    if (root != nullptr){
        // Follow the left child pointer until it finds the leftmost node of the tree
        TreeNode* x = root;
        while (x->left != nullptr){
            x = x->left;
        }
        // Return the data associated with the leftmost node
        return x->data;
    }
    // If the tree is empty, return a default element 
    else { 
        return DataType();   
    }
}

// min_key
template<typename DataType, typename KeyType>
KeyType BST<DataType, KeyType>::min_key(){

    // If the tree is not empty
    if (root != nullptr){
        // Follow the left child pointer until it finds the leftmost node of the tree
        TreeNode* x = root;
        while (x->left != nullptr){
            x = x->left;
        }
        // Return the key associated with the leftmost node
        return x->key;
    }
    // If the tree is empty, return a default element 
    else {
        return KeyType();       
    }
}

// successor
template<typename DataType, typename KeyType>
KeyType BST<DataType, KeyType>::successor(KeyType k) {
    
    // Get the node that has key k 
    TreeNode* x = search(root, k);

    // If there is a node with key k in the tree
    if (x != nullptr) {

        // Case 1: if x has a right subtree, the successor of x is the minimum element 
        // in x's right subtree
        if (x->right != nullptr) {
            x = x->right;
            while (x->left != nullptr){
                x = x->left;
            }
            return x->key;
        }
        // Case 2: if x does not have a right subtree, the successor of x is the lowest ancester
        // of x whose left child is an ancestor of x
        TreeNode* y = x->p;
        while (y!= nullptr and x == y->right) {
            x = y;
            y = y->p;
        }
        // If the successor of x exists, return the key of the successor
        if (y != nullptr)
            return y->key;
        // Otherwise, return a default element 
        else
            return KeyType();    
    }

    // If the tree is empty or there is no node with the target key, return a default element
    else {
        return KeyType();
    }
}

// successor_node: return the node of the successor 
template<typename DataType, typename KeyType>
typename BST<DataType, KeyType>::TreeNode* BST<DataType, KeyType>::successor_node(KeyType k) {
    // Get the node that has key k 
    TreeNode* x = search(root, k);

    // If there is a node with key k in the tree
    if (x != nullptr) {
        // Case 1: if x has a right subtree, the successor of x is the minimum element 
        // in x's right subtree
        if (x->right != nullptr) {
            x = x->right;
            while (x->left != nullptr){
                x = x->left;
            }
            return x;
        }
    
        // Case 2: if x does not have a right subtree, the successor of x is the lowest ancester
        // of x whose left child is an ancestor of x
        TreeNode* y = x->p;
        while (y!= nullptr and x == y->right) {
            x = y;
            y = y->p;
        }
        // If the successor of x exists, return that node
        if (y != nullptr)
            return y;
        // Otherwise, return NIL
        else
            return nullptr;    
    }
    
    // If the tree is empty or there is no node with the target key, return a default element
    else {
        return nullptr;
    }
}

template<typename DataType, typename KeyType>
void BST<DataType, KeyType>::traverse(TreeNode* x, stringstream& order)
{
    // If the tree is empty, return 
    if (this->empty())
        return;

    // If x is not NIL
    if (x != nullptr) {
        // Do the in-order tree walk and put the keys of each node into the string stream
        traverse(x->left, order); 
        order << x->key << ' ';
        traverse(x->right, order);
    }
}

// in_order 
template<typename DataType, typename KeyType>
string BST<DataType, KeyType>::in_order()
{
    stringstream result;
    // Use the helper function to put the keys into 'result' in ascending order
    traverse(root, result);

    // Convert the string stream into string and remove unnecessary space
    string in_order_str = result.str();
    in_order_str.pop_back();

    return in_order_str;
}

// trim_helper
template<typename DataType, typename KeyType> 
typename BST<DataType, KeyType>::TreeNode* BST<DataType, KeyType>::trim_helper(TreeNode* bst_root, KeyType low, KeyType high)
{
    // Base case: when the current node is NIL, return NIL
    if (bst_root == nullptr)
        return nullptr;

    // If the key of the current node is smaller than the lower bound, 
    // discard the left subtree of that node and return the root of the right subtree
    if (bst_root->key < low) {
        if (bst_root->right != nullptr)
            bst_root->right->p = nullptr;
        return trim_helper(bst_root->right, low, high);
    }
    // If the key of the current node is bigger than the upper bound,
    // discard the right subtree of that node and return the root of the left subtree
    else if (bst_root->key > high) {
        if (bst_root->left != nullptr)
            bst_root->left->p = nullptr;
        return trim_helper(bst_root->left, low, high);
    }
    // If the key of the current node lies in the interval, keep the node 
    // and perform recursive calls on its children to trim the rest of the tree
    else if (bst_root->key >= low && bst_root->key <= high)
    {
        bst_root->left = trim_helper(bst_root->left, low, high);
        bst_root->right = trim_helper(bst_root->right, low, high);
    }

    // Return the root of the trimmed tree
    return bst_root;
}

// trim
template<typename DataType, typename KeyType>
void BST<DataType, KeyType>::trim(KeyType low, KeyType high) 
{
    if (low > high) {
        return;
    }
    // Use the helper function to trim the BST according to the given interval
    this->root = trim_helper(this->root, low, high);
}

