# ifndef BINARY_SEARCH_TREE_H_
# define BINARY_SEARCH_TREE_H_

# include <string>
# include <sstream> 
# include <iostream> 
# include <queue>
# include <typeinfo>
using namespace std;

template<typename DataType, typename KeyType> 
class BST {
    public: 
        class TreeNode {
            public: 
                // data of the BST node 
                DataType data;
                // key of the BST node 
                KeyType key;
                // a pointer to the parent of the BST node 
                TreeNode* p;
                // a pointer to the left child of the BST node 
                TreeNode* left;
                // a pointer to the right child of the BST node 
                TreeNode* right; 

            /**
             * Constructor
             * Precondition: 'd' is the data of the node and 'k' is the key of the node
             * Postcondition: creates a new TreeNode object whose data is 'd' and key is 'k'
             */
            TreeNode(DataType d, KeyType k) {
                data = d;
                key = k;
                p = nullptr;
                left = nullptr;
                right = nullptr; 
            }
        };

        /**
         * Constructor
         * Precondition: none
         * Postcondition: creates an empty BST object 
         */
        BST();

        /**
         * Returns the string representation of the BST object
         * Precondition: none
         * Postcondition: returns the string representation of the BST object
         */
        string to_string();

        /**
         * Checks if the BST is empty or not
         * Precondition: none 
         * Postcondition: returns true if the BST is empty and false otherwise
         */
        bool empty(); 

        /**
         * Inserts a node with data d and key k into the BST
         * Precondition: 'd' is the data and 'k' is the key of the node to insert 
         * Postcondition: the node with data 'd' and key 'k' is inserted in the tree 
         * such that the BST property is preserved.
         */
        void insert(DataType d, KeyType k);

        /**
         * Returns the node with key k. If there is no node with such key, returns NULL
         * Precondition: 'x' is a valid node in the BST (the node to start the search)
         * and 'k' is the key to search for 
         * Postcondition: Searches the BST for the node with key k and returns the node with
         * such key or NULL if there is no such node
         */
        TreeNode* search(TreeNode* x, KeyType k);

        /**
         * Returns the data associated with the key k
         * Precondition: 'k' is the key in the BST 
         * Postcondition: returns the data of the node whose key is k. If the BST is empty 
         * or does not contain the node with key k, returns a default element 
         */
        DataType get(KeyType k);

        /**
         * Deletes the first node in the BST with key k 
         * Precondition: 'k' is the key in the BST 
         * Postcondition: the node with key k is removed from the BST 
         * while preserving the BST property 
         */
        void remove(KeyType k);

        /**
         * Returns the data associated with the max key in the BST 
         * Precondition: the BST has the binary search tree property
         * Postcondition: returns the data with the largest key in the BST. 
         * If the BST is empty, returns a default element
         */
        DataType max_data();

        /**
         * Returns the key associated with the max key in the BST 
         * Precondition: the BST has the binary search tree property
         * Postcondition: returns the largest key in the BST. If the BST is empty,
         * returns a default element
         */
        KeyType max_key();

        /**
         * Returns the data associated with the min key in the BST 
         * Precondition: the BST has the binary search tree property
         * Postcondition: returns the data with the smallest key in the BST.
         * If the BST is empty, returns a default element 
         */
        DataType min_data();

        /**
         * Returns the key associated with the min key in the BST 
         * Precondition: the BST has the binary search tree property 
         * Postcondition: returns the smallest key in the BST. If the BST is empty,
         * returns a default element
         */
        KeyType min_key();

        /**
         * Returns the successor key in the BST for the key k 
         * Precondition: the BST has the binary search tree property and 
         * k is the key that exists in the BST 
         * Postcondition: returns the successor key in the BST. If the BST is empty,
         * returns a default element 
         */
        KeyType successor(KeyType k);

        /**
         * Returns the successor node of the node with key k
         * Precondition: the BST has the binary search tree property and k is the key 
         * that exists in the BST
         * Postcondition: returns the successor node in the BST. If the BST is empty or does
         * not have a successor, returns NIL
         */
        TreeNode* successor_node(KeyType k);
        
        /**
         * Returns a string of the keys in the BST in increasing order 
         * Precondition: the BST has the binary search tree property 
         * Postcondition: returns the string of the keys in the BST in increasing order 
         */
        string in_order();

        /**
         * Trims the binary search tree bst so that the keys of every node lie 
         * in the interval [low, high] without changing the relative structure of the tree
         * Precondition: 'low' is the lower bound and 'high' is the upper bound of the interval
         * Postcondition: the BST is trimmed such that it only contains the nodes whose keys lie
         * in the interval [low, high]
         */
        void trim(KeyType low, KeyType high);

    private: 
        /**
         * Helper function of the remove method
         * Precondition: 'u' is not NIL 
         * Postcondition: the subtree rooted at 'u' is replaced with the subtree
         * rooted at 'v'
         */
        void transplant(TreeNode* u, TreeNode* v);

        /**
         * Helper function of the in_order method
         * Precondition: 'x' is the root of the BST and 'order' is an empty stringstream 
         * Postcondition: 'order' is the stringstream of the keys in the BST 
         * in ascending order separated by a single space
         */
        void traverse(TreeNode* x, stringstream& order);

        /**
         * Helper function of the trim method
         * Precondition: 'bst_root' is the root of the BST, 'low' and 'high' are the lower bound 
         * and the upper bound of the interval, respectively 
         * Postcondition: returns the root of the trimmed BST 
         */
        TreeNode* trim_helper(TreeNode* bst_root, KeyType low, KeyType high);

        // the root of the BST 
        TreeNode* root;
};

# endif
