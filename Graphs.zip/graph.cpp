# include "graph.h"
 
// default constructor
template<typename DataType, typename KeyType>
Graph<DataType, KeyType>::Graph()
{
}
 
// constructor
template<typename DataType, typename KeyType>
Graph<DataType, KeyType>::Graph(vector<KeyType> keys, vector<DataType> data, vector<vector<KeyType>> edges)
{
    // iterate the keys, create Vertex objects with the matching keys and data, and 
    // insert its keys as the keys of the graph object and the corresponding Vertex objects as the data 
    for (int i = 0; i < keys.size(); i++)
    {
            
        Vertex<DataType, KeyType> vertex(data[i], keys[i]);
        for (int j = 0; j < edges[i].size(); j++)
        {
            (vertex.l).push_back(edges[i][j]);
        }
        V.push_back(keys[i]);
        this->G.insert(pair<KeyType, Vertex<DataType, KeyType>>(keys[i], vertex));
    }

}
 
// destructor
template<typename DataType, typename KeyType>
Graph<DataType, KeyType>::~Graph()
{
    // deallocation
    for (auto &v : this->G)
    {
       delete v.first;
       delete v.second;
    }

    G.clear();
    delete V;
    delete time;
}

//is_empty
template<typename DataType, typename KeyType>
bool Graph<DataType, KeyType>::is_empty(){
    if (G.empty())
        return true;
    return false;
}

// contains-key
template<typename DataType, typename KeyType>
bool Graph<DataType, KeyType>::containsKey(KeyType k)
{
    // if the graph is empty, return false
    if (G.size() == 0) {
        return false;
    }
    

   // otherwise, check if G already contains a vertex with key k
    if (!G.count(k)) {
        return false;
    }
    
    return true;
}
 
// get
template<typename DataType, typename KeyType>
Vertex<DataType, KeyType>* Graph<DataType, KeyType>::get(KeyType k)
{
    // if G does not contain a vertex with key k, return NIL
    if (!containsKey(k))
        return nullptr;
        // otherwise, return the pointer to the vertex with key k
    return &(G.at(k));
}
 
// initialize
template<typename DataType, typename KeyType>
void Graph<DataType, KeyType>::initialize()
{
    // for each vertex object, set its color to white, distance to -1, and predecessor to NIL
   for (auto &v : this->G)
   {
       v.second.color = 0;
       v.second.d = -1;
       v.second.p = nullptr;
   }
}
 
// bfs-helper
template<typename DataType, typename KeyType>
void Graph<DataType, KeyType>::bfs_helper(KeyType s, bool print)
{
    // if G is empty, return 
    if (G.size() == 0) {
        return;
    }
    Vertex<DataType, KeyType>* src = get(s);   
    // if G does not contain a vertex with key s, return
    if (src == nullptr)
        return;
    initialize();
    //set the attributes of the source vertex
    src->color = 1;
    src->d = 0;
    src->p = nullptr;
    
    // initialize a queue and push the source vertex 
    queue<Vertex<DataType, KeyType>*> q;
    q.push(src);
    
    stringstream ss;
    // repeat the process until the queue gets empty
    while (!q.empty())
    {
        int n = q.size();
        for (int i = 0; i < n; i++)
        {
            Vertex<DataType, KeyType>* v = q.front();
            q.pop();
            // if the argument of the print parameter is true, print out the vertices
            // in bfs tree order
            if (print) 
            {
                if (i != n - 1)
                    ss << v->key << ' ';
                else
                    ss << v->key;
            }
            
            // iterate the adjacency list of the vertex that we took out from the queue
            // and if there is an undiscovered vertex in the list, process that vertex and
            // push it into queue
            for (KeyType k : v->l)
            {
                
                Vertex<DataType, KeyType>* adj_v = get(k);
                if (adj_v->color == 0)
                {
                    adj_v->color = 1;
                    adj_v->d = v->d + 1;
                    adj_v->p = v;
                    q.push(adj_v);
                }
            }
        }
        if (print)
            ss << '\n';
    }
    if (print) // print out the bfs-tree if requested
    {
        string str = ss.str();
        str.pop_back();
        cout << str;
    }
}
 
// bfs
template<typename DataType, typename KeyType>
void Graph<DataType, KeyType>::bfs(KeyType s)
{
    // execute bfs without printing out the bfs tree
   bfs_helper(s, false);
}
 
// reachable
template<typename DataType, typename KeyType>
bool Graph<DataType, KeyType>::reachable(KeyType u, KeyType v)
{
    // if G is empty, immediately return false
   if (G.size() == 0) {
       return false;
   }

   // if the given keys are not valid e.g. no vertices in G with such keys, return false
   if (!containsKey(u) || !containsKey(v))
       return false;
    
    // call bfs on the source vertex with key u 
   bfs(u);

   // if the vertex with key v is undiscovered after bfs, it means there is no path from u to v
   // therefore, return false
   if (get(v)->color == 0)
       return false;
   return true;
}
 
// print_path
template<typename DataType, typename KeyType>
void Graph<DataType, KeyType>::print_path(KeyType u, KeyType v)
{
    // if G is empty, immediately return
   if (G.size() == 0) {
       return;
   }
   
    // if the given keys are not valid e.g. no vertices in G with such keys, output empty string
   if (!containsKey(u) || !containsKey(v)) {
       cout << "";
       return;
   }
  
   // call bfs on the source vertex with key u
   bfs(u);
   stringstream path;
   // if there is no path from u to v, output empty string
   if (get(v)->color == 0)
   {
        cout << "";
        return;
   }

   // call the helper method and save its result into a stringstream object
   print_helper(get(u), get(v), path);
   string path_str = path.str();
   path_str.erase(path_str.end()-4, path_str.end());   // erase ' -> ' at the end
   cout << path_str;
}
 
// print-helper
template<typename DataType, typename KeyType>
void Graph<DataType, KeyType>::print_helper(Vertex<DataType, KeyType>* u, Vertex<DataType, KeyType>* v, stringstream& ss)
{
    // if it reaches the source vertex, print out the source vertex
   if (u == v)
       ss << u->key << " -> ";
    // this means there is no path from u to v 
   else if (v->p == nullptr)
       return;
   else {
        // make a recursive call on the predecessor of v to print out the successive keys
       print_helper(u, v->p, ss);
       ss << v->key << " -> "; 
   }
}
 
// bfs_tree
template<typename DataType, typename KeyType>
void Graph<DataType, KeyType>::bfs_tree(KeyType s)
{
    // execute bfs and also print out the bfs tree along the way
    bfs_helper(s, true);
}
 
// dfs
template<typename DataType, typename KeyType>
void Graph<DataType, KeyType>::dfs()
{
    // if G is empty, return
    if (G.size() == 0) {
        return; 
    }
    
    initialize();
    time = 0;
    // call dfs on undiscovered vertices
    for (KeyType u_key : this->V){
        Vertex<DataType, KeyType>* u = get(u_key);
        if (u != nullptr) {
                if (u->color == 0) {   
                    dfs_visit(u);
                }
        }
    }    
}
 
//dfs-visit
template<typename DataType, typename KeyType>
void Graph<DataType, KeyType>::dfs_visit(Vertex<DataType, KeyType>* u) {
    
    time = time + 1;
    u->start = time; // mark the discovery time
    u->color = 1; 
    
    for (KeyType v_key : u->l){
        Vertex<DataType, KeyType>* v = get(v_key);
        if (v != nullptr) {
                if (v->color == 0) {
                    v->p = u;
                    dfs_visit(v);
                }
        }
    }
    time = time + 1;
    u->end = time; // mark the finish time
}
 

//contain vertex_key- helper for edge class
template<typename DataType, typename KeyType>
bool Graph<DataType,KeyType>::contain_VerKey(Vertex <DataType, KeyType> *u, KeyType v){
bool found = (std::find(u->l.begin(), u->l.end(), v) != u->l.end());
 return found;
}

//edge-class
template<typename DataType, typename KeyType>
string Graph<DataType,KeyType>::edge_class(KeyType u, KeyType v)
{
  string result = "no edge";
  
  //check if empty graph  
  if (G.size() == 0){
      return result; 
  }

  //check whether exists U and V in the graph
  Vertex<DataType, KeyType>* U = get(u);
  Vertex<DataType, KeyType>* V = get(v);
  if ( U == nullptr ||  V == nullptr){
        result = "no edge";
        return result;}
        
  dfs();

  //check if V is reachable from U
  if (contain_VerKey(U,V->key))
  {
      if (V->p == U)
      {
          result = "tree edge";
      }
      else if ((V->start <= U->start) && ( U->end <= V->end))
      {
          result = "back edge";
      }
      else if ((U->start < V->start )&& (U->end > V->end))
      {
          result = "forward edge";
      }
      else if ((U->start > V->start)&& (U->end > V->end))
      {
          result = "cross edge";
      }
  }
  else {result = "no edge";}
  return result;
}
