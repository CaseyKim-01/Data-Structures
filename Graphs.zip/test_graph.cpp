# include "graph.h"
# include "graph.cpp"
#include <fstream>
 
Graph<string, string>* generate_graph(string fname){
   string line;
   ifstream infile(fname);
   vector<string> keys = {};
   vector<string> data = {};
   vector<vector<string>> adjs = {};
   if(infile.is_open()){ 
       while(getline(infile, line)){
           unsigned long delim = line.find(":");
           string key = line.substr(0, delim);
           string adj = line.substr(delim+1);
          
           keys.push_back(key);
           data.push_back(key + " data");
           delim = adj.find(",");
           vector<string> adj_lst = {};
           while(delim != string::npos){
               adj_lst.push_back(adj.substr(0, delim));
               adj = adj.substr(delim+1);
               delim = adj.find(",");
           }
           adj_lst.push_back(adj);
           adjs.push_back(adj_lst);
       }
   }
   Graph<string,string>* G = new Graph<string, string>(keys, data, adjs);
   return G;
}

// Testing graph G
void test_get_G(Graph<string,string>* G) {
   try {
       //empty graph
        Graph<string,string>* G_1a = new Graph<string, string>();
        if (G_1a->get("a") != nullptr){
            cout << "Incorrect result getting non-existant vertex from an empty graph" << endl;
        }
       //non-existant vertex 
        if (G->get("AA") != nullptr){
            cout << "Incorrect result getting non-existant vertex from the graph" << endl;
        }
       
       //existant 
        if (G->get("Y") == nullptr || G->get("Y")->data != "Y data"){
            cout << "Incorrect result getting vertex from the graph" << endl;
        }

      
       if(G->get("S")==nullptr || G->get("S")->data != "S data") {
           cout << "Incorrect result getting vertex \"s\"" << endl; 
       }
       if(G->get("a") != nullptr) {
           cout << "Incorrect result getting non-existant vertex \"a\"" << endl;
       }
   } catch(exception& e) {
       cerr << "Error getting vertex from graph : " << e.what() << endl;
   }
}
 
void test_bfs_G(Graph<string,string>* G) {
   try {
        // test case 1 
        G->bfs("A");
        string vertices1[8] = {"V", "R", "S", "W", "T", "X", "U", "Y"};
        int distances1[8] = {-1,-1,-1,-1,-1,-1,-1,-1};
        for(int i = 0; i < 8; i++){
           if(G->get(vertices1[i])==nullptr || G->get(vertices1[i])->d != distances1[i]) {
               cout << "Incorrect bfs result. Vertex " << vertices1[i] << "should have distance " << distances1[i] << " from source vertex \"A\"" << endl;
           }
       }

        // test case 2
       G->bfs("T");
       string vertices2[8] = {"V", "R", "S", "W", "T", "X", "U", "Y"};
       int distances2[8] = {3,2,1,1,0,2,1,2};
       for(int i = 0; i < 8; i++){
           if(G->get(vertices2[i])==nullptr || G->get(vertices2[i])->d != distances2[i]) {
               cout << "Incorrect bfs result. Vertex " << vertices2[i] << "should have distance " << distances2[i] << " from source vertex \"T\"" << endl;
           }
       }

       // test case 3 
       G->bfs("V");
       string vertices3[8] = {"V", "R", "S", "W", "T", "X", "U", "Y"};
       int distances3[8] = {0,2,1,-1,-1,-1,-1,-1};
       for(int i = 0; i < 8; i++){
           if(G->get(vertices3[i])==nullptr || G->get(vertices3[i])->d != distances3[i]) {
               cout << "Incorrect bfs result. Vertex " << vertices3[i] << "should have distance " << distances3[i] << " from source vertex \"V\"" << endl;
           }
       }

       // test case 4
       G->bfs("X");
       string vertices4[8] = {"V", "R", "S", "W", "T", "X", "U", "Y"};
       int distances4[8] = {-1,-1,-1,3,-1,0,1,2};
       for(int i = 0; i < 8; i++){
           if(G->get(vertices4[i])==nullptr || G->get(vertices4[i])->d != distances4[i]) {
               cout << "Incorrect bfs result. Vertex " << vertices4[i] << "should have distance " << distances4[i] << " from source vertex \"X\"" << endl;
           }
       }
        
        //test case 5
        Graph<string,string>* G_empty = new Graph<string, string>();
        G_empty->bfs("A");
        if (!G_empty->is_empty()) 
            cout << "Incorrect bfs result. Expected an empty graph" << endl;
        
       
   } catch(exception& e) {
       cerr << "Error testing bfs : " << e.what() << endl;
   }
}

 
void test_reachable_G(Graph<string,string>* G) {
   try {
    
        //test1 
       if (!G->reachable("R", "S")) {
           cout << "Incorrectly identified adjacent vertex \"S\" as unreachable from \"R\"" << endl;
       }
        //test2
       if(G->reachable("B", "A")) {
           cout << "Incorrectly identified non-existant vetex \"A\" as reachable from non-existant \"B\"" << endl;
       }

        //test3
       if(!G->reachable("R", "V")) {
           cout << "Incorrectly identified adjacent vertex \"V\" as unreachable from \"R\"" << endl;
       }

        //test4
       if(!G->reachable("X", "W")) {
           cout << "Incorrectly identified \"W\" as reachable from \"X\"" << endl;
       }

       //test5
       if(G->reachable("S", "A")) {
           cout << "Incorrectly identified non-existant vetex \"A\" as reachable from \"S\"" << endl;
       }
   } catch(exception& e) {
       cerr << "Error testing reachable : " << e.what() << endl;
   }
}

void test_print_path_G(Graph<string,string>* G) {
   try {
        // test case 1
        stringstream buffer1;
        streambuf* prevbuf1 = cout.rdbuf(buffer1.rdbuf());
       G->print_path("A", "T");
       cout.rdbuf(prevbuf1);
       if(buffer1.str()!="") {
           cout << "Incorrect path from vertex \"A\" to vertex \"T\". Expected: empty string but got : " << buffer1.str() << endl;
       }

        // test case 2
       stringstream buffer2;
       streambuf* prevbuf2 = cout.rdbuf(buffer2.rdbuf());
       G->print_path("T", "V");
       cout.rdbuf(prevbuf2);
       if(buffer2.str()!="T -> S -> R -> V") {
           cout << "Incorrect path from vertex \"T\" to vertex \"V\". Expected: T -> S -> R -> V but got : " << buffer2.str() << endl;
       }

        // test case 3
       stringstream buffer3;
       streambuf* prevbuf3 = cout.rdbuf(buffer3.rdbuf());
       G->print_path("X", "W");
       cout.rdbuf(prevbuf3);
       if(buffer3.str()!="X -> U -> Y -> W") {
           cout << "Incorrect path from vertex \"X\" to vertex \"W\". Expected: X -> U -> Y -> W  but got : " << buffer3.str() << endl;
       }

       // test case 4
       stringstream buffer4;
       streambuf* prevbuf4 = cout.rdbuf(buffer4.rdbuf());
       G->print_path("R", "X");
       cout.rdbuf(prevbuf4);
       if(buffer4.str()!="") {
           cout << "Incorrect path from vertex \"R\" to vertex \"X\". Expected: empty string  but got : " << buffer4.str() << endl;
       }

   } catch(exception& e) {
       cerr << "Error testing print path : " << e.what() << endl;
   }
}
 
void test_bfs_tree_G(Graph<string,string>* G) {
    try {
        //test case 1
        stringstream buffer;
        streambuf* prevbuf = cout.rdbuf(buffer.rdbuf());
        G->bfs_tree("T");
        cout.rdbuf(prevbuf);
        if(buffer.str() != "T\nS U W\nR Y X\nV") {
            cout << "Incorrect bfs tree. Expected : \nT\nS U W\nR Y X\nV \nbut got :\n" << buffer.str() << endl;
        }
        
        //test case 2
        stringstream buffer2;
        streambuf* prevbuf2 = cout.rdbuf(buffer2.rdbuf());
        G->bfs_tree("L");
        cout.rdbuf(prevbuf2);
        if(buffer2.str() != "") {
            cout << "Incorrect bfs tree. Expected an empty string but got :\n" << buffer2.str() << endl;
        }

        //test case 3
        stringstream buffer3;
        streambuf* prevbuf3 = cout.rdbuf(buffer3.rdbuf());
        G->bfs_tree("U");
        cout.rdbuf(prevbuf3);
        if(buffer3.str() != "U\nY\nW\nX") {
            cout << "Incorrect bfs tree. Expected \nU\nY\nW\nX\n but got :\n" << buffer3.str() << endl;
        }

        //test case 4
        Graph<string,string>* G2 = new Graph<string, string>();
        stringstream buffer4;
        streambuf* prevbuf4 = cout.rdbuf(buffer4.rdbuf());
        cout.rdbuf(prevbuf4);
        G2->bfs_tree("T");
        if(buffer4.str() != "") {
            cout << "Incorrect bfs tree. Expected an empty string but got :\n" << buffer4.str() << endl;
        }


        
    } catch(exception& e) {
        cerr << "Error testing bfs tree : " << e.what() << endl;
    }
    
}
 
void test_dfs_G(Graph<string,string>* G) {
    try {
        //Test case 1
        G->dfs();
        string vertices[8] = {"R", "V", "S", "T", "U", "Y", "W", "X"};
        string parents[8] = {"NIL", "R", "V", "NIL", "T", "U", "Y", "W"};
        int starts[8] = {1,2,3,7,8,9,10,11};
        int ends[8] = {6,5,4,16,15,14,13,12};
        for(int i = 0; i < 8; i++){
            Vertex<string,string>* u = G->get(vertices[i]);
            if (u == nullptr)
                cout << "Incorrect dfs result. Vertex " << vertices[i] << " doesn't exist.";

            if (u->p != nullptr){
                if (u->p->key != parents[i])
                    cout << "Incorrect dfs result. Vertex " << vertices[i] << "should have " << parents[i] << " as its parent but instead have " << u->p->key << endl;
            }
            else {
                if (parents[i] != "NIL")
                    cout << "Incorrect dfs result. Vertex " << vertices[i] << "should have " << parents[i] << " as its parent but instead have no parent" << endl;
            }
            
            if(u->start != starts[i]) {
                cout << "Incorrect dfs result. Vertex " << vertices[i] << "should have been discovered at " << starts[i] << " but instead at " << u->start << endl; 
            }
            if(u->end != ends[i]) {
                cout << "Incorrect dfs result. Vertex " << vertices[i] << "should have been finished at " << ends[i] << " but instead at " << u->end << endl; 
            }  
        }

        //Test case 2
        Graph<string,string>* G2 = new Graph<string, string>();
        G2->dfs();
        if (!G2->is_empty()) 
            cout << "Incorrect dfs result. Expected an empty graph" << endl;

   } catch(exception& e) {
       cerr << "Error testing dfs : " << e.what() << endl;
   }
}  
   
void test_edge_class_G(Graph<string,string>* G) {
   try {

       //empty graph
        Graph<string,string>* G3 = new Graph<string, string>();
        string e3_class =  G3->edge_class("X", "S"); 
        if(e3_class != "no edge") {
           cout << "Misidentified non-existant edge (\"X\", \"S\") for an empty graph as : " << e3_class << endl;
        }

       //both non-existant vertex

       string e3a_class = G-> edge_class("L","O");
       if (e3a_class != "no edge"){
           cout << "Misidentidied non-existant edges as " << e3a_class << endl;
       }

       //one non-existant vertex
       string e3b_class = G-> edge_class("T","O");
       if (e3b_class != "no edge"){
           cout << "Misidentidied non-existant edge as " << e3a_class << endl;
       }

       //no edge 
       string e3c_class = G-> edge_class("Y","U");
       if (e3c_class != "no edge"){
           cout << "Misidentidied no edge as " << e3c_class << endl;
       }

       //tree edge
       string e3c1_class = G-> edge_class("W","X");
       if (e3c1_class != "tree edge"){
           cout << "Misidentidied tree edge as " << e3c1_class << endl;
       }

       //back edge
       string e3d_class = G-> edge_class("S","R");
       if (e3d_class != "back edge"){
           cout << "Misidentidied back edge as " << e3d_class << endl;
       }
       

       //cross edge 
       string e3f_class = G-> edge_class("T","S");
       if (e3f_class != "cross edge"){
           cout << "Misidentidied cross edge as " << e3f_class << endl;
       }
       
       string e_class =  G->edge_class("X", "U"); 
       if(e_class != "back edge") {
           cout << "Misidentified tree edge (\"X\", \"R\") as : " << e_class << endl;
       }
   } catch(exception& e) {
       cerr << "Error testing edge class : " << e.what() << endl;
   }
  
}
 
// Testing graph K
void test_bfs_K(Graph<string,string>* K)
{
    try {
        // test case 1
        Graph<string,string>* K_empty = new Graph<string, string>();
        K_empty->bfs("A");
        if (!K_empty->is_empty()) 
            cout << "Incorrect bfs result. Expected an empty graph" << endl;
        
        // test case 2 
        K->bfs("O");
        string vertices1[6] = {"U", "V", "W", "X", "Y", "Z"};
        int distances1[6] = {-1,-1,-1,-1,-1,-1};
        for(int i = 0; i < 6; i++){
           if(K->get(vertices1[i])==nullptr || K->get(vertices1[i])->d != distances1[i]) {
               cout << "Incorrect bfs result. Vertex " << vertices1[i] << "should have distance " << distances1[i] << " from source vertex \"O\"" << endl;
           }
       }

       // test case 3
       K->bfs("W");
       string vertices3[6] = {"U", "V", "W", "X", "Y", "Z"};
       int distances3[6] = {-1,3,0,2,1,1};
       for(int i = 0; i < 6; i++){
           if(K->get(vertices3[i])==nullptr || K->get(vertices3[i])->d != distances3[i]) {
               cout << "Incorrect bfs result. Vertex " << vertices3[i] << "should have distance " << distances3[i] << " from source vertex \"W\"" << endl;
           }
       }

       // test case 4
       K->bfs("Z");
       string vertices4[6] = {"U", "V", "W", "X", "Y", "Z"};
       int distances4[6] = {-1,-1,-1,-1,-1,0};
       for(int i = 0; i < 6; i++){
           if(K->get(vertices4[i])==nullptr || K->get(vertices4[i])->d != distances4[i]) {
               cout << "Incorrect bfs result. Vertex " << vertices4[i] << "should have distance " << distances4[i] << " from source vertex \"Z\"" << endl;
           }
       }

       // test case 5
        K->bfs("U");
        string vertices5[6] = {"U", "V", "W", "X", "Y", "Z"};
       int distances5[6] = {0,1,-1,1,2,-1};
       for(int i = 0; i < 6; i++){
           if(K->get(vertices5[i])==nullptr || K->get(vertices5[i])->d != distances5[i]) {
               cout << "Incorrect bfs result. Vertex " << vertices5[i] << "should have distance " << distances5[i] << " from source vertex \"U\"" << endl;
           }
       }

   } catch(exception& e) {
       cerr << "Error testing bfs : " << e.what() << endl;
   }
}

void test_print_path_K(Graph<string,string>* K)
{
    try {
        // test case 1 
        stringstream buffer1;
        streambuf* prevbuf1 = cout.rdbuf(buffer1.rdbuf());
       K->print_path("Z", "W");
       cout.rdbuf(prevbuf1);
       if(buffer1.str()!="") {
           cout << "Incorrect path from vertex \"Z\" to vertex \"W\". Expected: empty string but got : " << buffer1.str() << endl;
       }

       // test case 2
       stringstream buffer2;
       streambuf* prevbuf2 = cout.rdbuf(buffer2.rdbuf());
       K->print_path("W", "X");
       cout.rdbuf(prevbuf2);
       if(buffer2.str()!="W -> Y -> X") {
           cout << "Incorrect path from vertex \"W\" to vertex \"Z\". Expected: W -> Y -> X but got : " << buffer2.str() << endl;
       }

        // test case 3
       stringstream buffer3;
       streambuf* prevbuf3 = cout.rdbuf(buffer3.rdbuf());
       K->print_path("X", "Y");
       cout.rdbuf(prevbuf3);
       if(buffer3.str()!="X -> V -> Y") {
           cout << "Incorrect path from vertex \"X\" to vertex \"Y\". Expected: X -> V -> Y  but got : " << buffer3.str() << endl;
       }

       //test case 4
       stringstream buffer4;
       streambuf* prevbuf4 = cout.rdbuf(buffer4.rdbuf());
       K->print_path("U", "Y");
       cout.rdbuf(prevbuf4);
       if(buffer4.str()!="U -> V -> Y") {
           cout << "Incorrect path from vertex \"U\" to vertex \"Y\". Expected: U -> V -> Y  but got : " << buffer4.str() << endl;
       }

   } catch(exception& e) {
       cerr << "Error testing print path : " << e.what() << endl;
   }
}





void test_bfs_tree_K(Graph<string,string>* K) {
    try {
        //test case 1
        stringstream buffer;     

        streambuf* prevbuf = cout.rdbuf(buffer.rdbuf());
        K->bfs_tree("U");
        cout.rdbuf(prevbuf);
        if(buffer.str() != "U\nV X\nY") {
            cout << "Incorrect bfs tree. Expected : \nU\nV X\nY\n but got :\n" << buffer.str() << endl;
        }
        
        //Test case 2
        stringstream buffer2;
        streambuf* prevbuf2 = cout.rdbuf(buffer2.rdbuf());
        K->bfs_tree("W");
        cout.rdbuf(prevbuf2);
        if(buffer2.str() != "W\nY Z\nX\nV") {
            cout << "Incorrect bfs tree. Expected : \nW\nY Z\nX\nV\n but got :\n" << buffer2.str() << endl;
        }

        // //Test case 3
        stringstream buffer3;
        streambuf* prevbuf3 = cout.rdbuf(buffer3.rdbuf());
        K->bfs_tree("Z");
        cout.rdbuf(prevbuf3);
        if(buffer3.str() != "Z") {
            cout << "Incorrect bfs tree. Expected : \nZ\n but got :\n" << buffer3.str() << endl;
        }
        
    } catch(exception& e) {
        cerr << "Error testing bfs tree : " << e.what() << endl;
    }
    
}

void test_get_K(Graph<string,string>* K) {
   try {
       //empty graph
        Graph<string,string>* K_1a = new Graph<string, string>();
        if (K_1a->get("a") != nullptr){
            cout << "Incorrect result getting non-existant vertex from an empty graph" << endl;
        }

       //non-existant vertex 
        if (K->get("AA") != nullptr){
            cout << "Incorrect result getting non-existant vertex from the graph" << endl;
        }
       
       //existant 
        if (K->get("Z") == nullptr || K->get("Z")->data != "Z data"){
            cout << "Incorrect result getting vertex from the graph" << endl;
        }

      
       if(K->get("X")==nullptr || K->get("X")->data != "X data") {
           cout << "Incorrect result getting vertex \"x\"" << endl; 
       }

   } catch(exception& e) {
       cerr << "Error getting vertex from graph : " << e.what() << endl;
   }
}

void test_reachable_K(Graph<string,string>* K) {
   try {
        //test1 
       if (!K->reachable("X", "Y")) {
           cout << "Incorrectly identified adjacent vertex \"X\" as unreachable from \"Y\"" << endl;
       }
        //test2
       if(K->reachable("B", "W")) {
           cout << "Incorrectly identified  vetex \"W\" as reachable from non-existant \"B\"" << endl;
       }

        //test3
       if(!K->reachable("W", "X")) {
           cout << "Incorrectly identified adjacent vertex \"X\" as unreachable from \"W\"" << endl;
       }

        //test4
       if(K->reachable("U", "Z")) {
           cout << "Incorrectly identified \"Z\" as reachable from \"W\"" << endl;
       }

       //test5
       if(K->reachable("V", "L")) {
           cout << "Incorrectly identified non-existant vetex \"L\" as reachable from \"V\"" << endl;
       }
   } catch(exception& e) {
       cerr << "Error testing reachable : " << e.what() << endl;
   }
}

void test_edge_class_K(Graph<string,string>* K) {
   try {

       //empty graph
        Graph<string,string>* K3 = new Graph<string, string>();
        string e3_class =  K3->edge_class("L", "S"); 
        if(e3_class != "no edge") {
           cout << "Misidentified non-existant edge (\"X\", \"S\") for an empty graph as : " << e3_class << endl;
        }

       //both non-existant vertex

       string e3a_class = K-> edge_class("Q","l");
       if (e3a_class != "no edge"){
           cout << "Misidentidied non-existant edges as " << e3a_class << endl;
       }

       //one non-existant vertex
       string e3b_class = K-> edge_class("W","O");
       if (e3b_class != "no edge"){
           cout << "Misidentidied non-existant edge as " << e3a_class << endl;
       }

       //no edge 
       string e3c_class = K-> edge_class("U","Z");
       if (e3c_class != "no edge"){
           cout << "Misidentidied no edge as " << e3c_class << endl;
       }

       //no edge for non-existant self-loop
       string e3c0_class = K-> edge_class("U","U");
       if (e3c0_class != "no edge"){
           cout << "Misidentidied no edge as " << e3c0_class << endl;
       }

       //tree edge
       string e3c1_class = K-> edge_class("V","Y");
       if (e3c1_class != "tree edge"){
           cout << "Misidentidied tree edge as " << e3c1_class << endl;
       }

       //back edge
       string e3d_class = K-> edge_class("X","V");
       if (e3d_class != "back edge"){
           cout << "Misidentidied back edge as " << e3d_class << endl;
       }

       //back edge for self-loop
       string e3d1_class = K-> edge_class("Z","Z");
       if (e3d1_class != "back edge"){
           cout << "Misidentidied self-loop back edge as " << e3d1_class << endl;
       }

       
       //forward edge
       string e3e_class = K-> edge_class("U","X");
       if (e3e_class != "forward edge"){
           cout << "Misidentidied forward edge of graph K as " << e3e_class << endl;
       }

       //cross edge 
       string e3f_class = K-> edge_class("W","Y");
       if (e3f_class != "cross edge"){
           cout << "Misidentidied cross edge as " << e3f_class << endl;
       }
       
   } catch(exception& e) {
       cerr << "Error testing edge class : " << e.what() << endl;
   }
  
}


void test_dfs_K(Graph<string,string>* K) {
    try {
        //Test case 1
        K->dfs();
        string vertices[6] = {"U", "V", "X", "Y", "W", "Z"};
        string parents[8] = {"NIL", "U", "Y", "V", "NIL", "W"};
        int starts[6] = {1,2,4,3,9,10};
        int ends[6] = {8,7,5,6,12,11};
        for(int i = 0; i < 6; i++){
            Vertex<string,string>* u = K->get(vertices[i]);
            if (u == nullptr)
                cout << "Incorrect dfs result. Vertex " << vertices[i] << " doesn't exist.";

            if (u->p != nullptr){
                if (u->p->key != parents[i])
                    cout << "Incorrect dfs result. Vertex " << vertices[i] << "should have " << parents[i] << " as its parent but instead have " << u->p->key << endl;
            }
            else {
                if (parents[i] != "NIL")
                    cout << "Incorrect dfs result. Vertex " << vertices[i] << "should have " << parents[i] << " as its parent but instead have no parent" << endl;
            }
            
            if(u->start != starts[i]) {
                cout << "Incorrect dfs result. Vertex " << vertices[i] << "should have been discovered at " << starts[i] << " but instead at " << u->start << endl; 
            }
            if(u->end != ends[i]) {
                cout << "Incorrect dfs result. Vertex " << vertices[i] << "should have been finished at " << ends[i] << " but instead at " << u->end << endl; 
            }  
        }


   } catch(exception& e) {
       cerr << "Error testing dfs : " << e.what() << endl;
   }
}  


int main()
{
   Graph<string,string>* G = generate_graph("graph_description.txt");
   Graph<string,string>* K = generate_graph("graph_description2.txt");
   test_get_G(G);
   test_bfs_G(G);
   test_reachable_G(G);
   test_print_path_G(G);
   test_bfs_tree_G(G);
   test_dfs_G(G);
   test_edge_class_G(G);

   test_get_K(K);
   test_bfs_K(K);
   test_reachable_K(K);
   test_print_path_K(K);
   test_bfs_tree_K(K);
   test_dfs_K(K);
   test_edge_class_K(K);
   
   cout << "Testing completed" << endl;
}
 