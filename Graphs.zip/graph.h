# ifndef GRAPH_H_
# define GRAPH_H_
 
# include <iostream>
# include <list>
# include <sstream>
# include <queue>
# include <unordered_map>
# include <algorithm>
using namespace std;
 
template<typename DataType, typename KeyType>
class Vertex {
   public:
       // data of the vertex
       DataType data;
       // key of the vertex
       KeyType key;
       // distance of the vertex
       int d;
       // predecessor of the vertex
       Vertex<DataType, KeyType>* p;
       // color of the vertex
       bool color;
       // adjacency list of the vertex
       list<KeyType> l;
       int start;
       int end;
  
   /**
    * Default Constructor
    * Precondition: None
    * Postcondition: creates a new Vertex object
    */
   Vertex<DataType, KeyType>() {
       this->data = DataType();
       this->key = KeyType();
       this->d = -1;
       color = 0;
       this->p = nullptr;
       this->start = 0;
       this->end = 0;
   }

   /**
    * Constructor
    * Precondition: 'd' is the data of the vertex and 'k' is the key of the vertex
    * Postcondition: creates a new Vertex object whose data is 'd' and key is 'k'
    */
   Vertex<DataType, KeyType>(DataType d, KeyType k) {
       this->data = d;
       this->key = k;
       this->d = -1;
       color = 0;
       this->p = nullptr;
       this->start = 0;
       this->end = 0;
   }
};
 
template<typename DataType, typename KeyType>
class Graph { 
    // Map that stores the given graph information
    unordered_map<KeyType, Vertex<DataType, KeyType>> G;
    // time is a variable used for timestamping
    int time;
    // vector of keys
    vector<KeyType> V;

   /**
    * Helper method of print_path method
    * Precondition: 'u' and 'v' are the pointers to vertices and 'ss' is an empty stringstream object
    * Postcondition: prints a shortest path from the vertex in G corresponding
    * to the key u to the vertex in G corresponding to the key v.
    */
    void print_helper(Vertex<DataType, KeyType>* u, Vertex<DataType, KeyType>* v, stringstream& ss);
 
   /**
    * Helper method of bfs and bfs_tree methods
    * Precondition: 's' is the key of the source vertex and 'print' indicates whether to
    * print out the bfs tree along the breadth-first search process
    * Postcondition: executes bfs, prints out the bfs tree if 'print' is true.
    * Otherwise, simply executes bfs on G
    */
   void bfs_helper(KeyType s, bool print);
 
   /**
    * Initializes vertex attributes
    * Precondition: none
    * Postcondition: initializes the attributes of every vertex in G as the following:
    * color = 0, d = -1, p = NULL
    */
   void initialize();

   /**
    * Helper method for edge_class to see whether a vertex v is reachable from another vertex u 
    * Precondition: There must exist vertices v and u in the graph 
    * Postcondition: return true if vertex v is reachable from u and false otherwise
    */
    bool contain_VerKey(Vertex <DataType, KeyType> *u, KeyType v);

    /**
    * Helper method of dfs method
    * Precondition: the vertex 'u' is undiscovered
    * Postcondition: every vertex that is reachable from 'u' is discovered 
    */
    void dfs_visit(Vertex<DataType, KeyType>* u);
 
   public:
        /**
        * Default Constructor
        * Precondition: None
        * Postcondition: creates a new empty Graph object G
        */
        Graph<DataType, KeyType>();
    
        /**
        * Constructor
        * Precondition: 'keys' is a vector of vertex keys, 'data' is a vector of the
        * corresponding vertex data in matching order, and edges is a vector of vectors
        * representing the adjacency lists of the vertices in matching order
        * Postcondition: creates a new Graph object G from the given specifications
        */
        Graph<DataType, KeyType>(vector<KeyType> keys, vector<DataType> data, vector<vector<KeyType>> edges);

        /**
        * Destructor
        * Precondition: none
        * Postcondition: deallocates the memory used by the graph object G
        */
        ~Graph<DataType, KeyType>();

        /**
        * Checks if there exists a vertex in G with the given key
        * Precondition: 'k' is the key of a vertex that we want to check for
        * Postcondition: returns true if G contains a vertex with the key 'k'
        * and false otherwise
        */
        bool containsKey(KeyType k);
    
        /**
        * Returns the pointer to the vertex in G whose key is 'k'
        * Precondition: 'k' is the key of a vertex that we want to get
        * Postcondition: returns the pointer to the vertex with key 'k' if G contains
        * a vertex with such key. Otherwise, returns a null pointer
        */
        Vertex<DataType, KeyType>* get(KeyType k);
    
        /**
        * Checks if the vertex corresponding to the key v is reachable
        * from the vertex corresponding to the key u
        * Precondition: 'u' and 'v' are the keys of the vertices in G
        * Postcondition: returns true if the vertex with key v is reachable from
        * the vertex with key u and false otherwise. If there are no vertices that have
        * keys u and v, returns false
        */
        bool reachable(KeyType u, KeyType v);
    
        /**
         * Checks if the graph object G is empty
         * Precondition: none
         * Postcondition: returns true if G is empty and false otherwise
         */
        bool is_empty();
            
        /**
        * Executes the breadth-first search algorithm on G from the source vertex
        * with key 's'
        * Precondition: 's' is the key of the vertex in G that we want to start bfs
        * Postcondition: every vertex in G that is reachable from 's' is discovered and
        * the bfs tree is encoded in G
        */
        void bfs(KeyType s);
    
        /**
        * Prints a shortest path from the vertex with key 'u' to the vertex with key 'v'
        * Precondition: 'u' and 'v' are the keys of the vertices in G
        * Postcondition: prints a shortest path from the vertex with key 'u' to the
        * vertex with key 'v'. If there is no path from 'u' to 'v', prints nothing
        */
        void print_path(KeyType u, KeyType v);
    
        /**
        * Prints the bfs tree for the source vertex corresponding to the key s
        * Precondition: 's' is the key of the vertex in G that we want to start bfs
        * Postcondition: prints out the bfs tree of G when bfs is executed on the source
        * vertex 's'
        */
        void bfs_tree(KeyType s);
        
        /**
        * Executes the depth-first search algorithm on G
        * Precondition: none
        * Postcondition: every vertex in G is discovered and timestamp is saved in
        * each vertex throughout depth-first search
        */
        void dfs();

        /**
        * Returns the edge classification of the edge from vertex with key 'u' to
        * the vertex with key 'v'
        * Precondition: 'u' and 'v' are the keys of the vertices in G
        * Postcondition: returns the string representation of the edge classification 
        * (tree edge, back edge, forward edge, cross edge, or no edge)
        */
        string edge_class(KeyType u, KeyType v);

        
      
};
 
# endif
