# ifndef HASH_TABLE_H_
# define HASH_TABLE_H_ 

# include <iostream>
# include <string> 
# include <list> 
# include <sstream> 
# include <cmath>
# include <cstdlib>
using namespace std;

template<typename T>
class Element {
    private:
        long long int key;
        T data; 

    public: 
        /**
         * Default Constructor
         * Precondition: None 
         * Postcondition: creates an empty Element Object whose key is -1 and data is 0
         */
        Element() {
            key = -1;
            data = T();
        };

        /**
         * Custom Constructor
         * Precondition: 'initData' is the template data and 'initKey' is the numeric key value 
         * Postcondition: creates a new Element object whose key is initKey and data is initData
         */
        Element(T initData, long long int initKey) {
            key = initKey;
            data = initData;
        }

        /**
         * Returns the element’s numeric key value
         * Precondition: none 
         * Postcondition: returns the numeric key value of the element
         */
        long long int get_key() {
            return key;
        }

        /**
         * Returns the element's template data
         * Precondition: none
         * Postcondition: returns the template data of the element 
         */
        T get_data() {
            return data;
        }
};

template<typename T> 
class HashTable {
    private:
        list<Element<T>>* table;
        int size; 
    public: 
        
        /**
         * Constructor
         * Precondition: none 
         * Postcondition: creates a new HashTable object whose size is equal to 'num_slot'
         */
        HashTable(int num_slots);

        /**
         * Destructor
         * Precondition: none
         * Postcondition: deallocates the memory that was dynamically allocated by the hashtable object
         */
        ~HashTable();

        /**
         * Hash Function
         * Precondition: 'k' is the key value of the element
         * Postcondition: returns the hash value, which is the index in the hash table, of 'k'
         */
        unsigned int get_hash(long long int k);

        /**
         * Inserts an element with data 'data' and key 'key' into the hash table
         * Precondition: 'data' is the template data and 'key' is the numeric key value of the element 
         * to be inserted into the hash table 
         * Postcondition: the element with data 'data' and key 'key' is inserted at the head of the corresponding chain
         * in the hash table. The resulting hash table should contain the new element in slot h(key) ∈ {0,..., num_slots-1} for hash function h 
         */
        void insert(T data, int key);

        /**
         * Inserts an element with data 'data' and key 'key' into the hash table.
         * This insert method is specific to the usecase.
         * Precondition: 'data' is the template data(username) and 'key' is the numeric key value(password) of the element 
         * to be inserted into the hash table 
         * Postcondition: the element with data 'data' and key value of -1 is inserted at the head of the corresponding chain
         * in the hash table. The resulting hash table should contain the new element in slot h(key) ∈ {0,..., num_slots-1} for hash function h 
         */
        void insert(T data, long long int key);

        /**
         * Deletes the element with key 'k' from the hash table 
         * Precondition: 'k' is the numeric key value of the element to be deleted from the hash table
         * Postcondition: the element with key 'k' is deleted from the hash table
         */
        void remove(long long int k);

        /**
         * Checks if the element with data 'd' and key 'k' exists in the hash table
         * Precondition: 'd' is the template data and 'k' is the numeric key value of an element
         * Postcondition: returns true if the element with data 'd' and key 'k' is in the hash table and 
         * false otherwise
         */
        bool member(T d, int k);

        /**
         * Checks if the element with data 'd' and key 'k' exists in the hash table.
         * This member method is specific to the usecase.
         * Precondition: 'd' is the template data(username) and 'k' is the numeric key value(password) of an element
         * Postcondition: returns true if the element with data 'd' is in the hash table and 
         * false otherwise
         */
        bool member(T d, long long int k);

        /**
         * Checks if the element with key 'k' exists in the hash table
         * Precondition: 'k' is the numeric key value of an element
         * Postcondition: returns true if the element with key 'k' is in the hash table and false otherwise
         */
        bool contains(long long int k);
       
        /**
         * Precondition: none
         * Postcondition: returns the string representation of the HashTable object
         */
        string to_string();
};
#endif 
