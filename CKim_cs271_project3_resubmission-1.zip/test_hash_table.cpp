# include "hash_table.h"
# include "hash_table.cpp"
using namespace std; 

void test_get_key() {
    try { 
        //Test case 1
        Element<int> empty_elem;
        if(empty_elem.get_key()!= -1){cout << "Incorrect result from get key. Expected -1 for an empty element but got : " << empty_elem.get_key() << endl;}

        //Test case 2
        Element<int> e1(10, 6);
        if(e1.get_key()!= 6){cout << "Incorrect result from get key. Expected 6 but got : " << e1.get_key() << endl;}
        
        //Test case 3
        Element<string> e2("string data", 19000);
        if(e2.get_key()!= 19000){cout << "Incorrect result from get key. Expected 19000 but got : " << e2.get_key() << endl;}

        //Test case 4
        Element<double> e3(1.89, 100000000);
        if(e3.get_key()!= 100000000){cout << "Incorrect result from get key. Expected 100000000 but got : " << e2.get_key() << endl;}

    } catch(exception& e) {
        cerr << "Error getting key from element : " << e.what() << endl;
    }
} 

void test_get_data() {
    try {
        //Test case 1
        Element<int> empty_elem;
        if(empty_elem.get_data()!=0){cout << "Incorrect result from get data. Expected 0 for an empty element but got : " << empty_elem.get_data() << endl;}

        //Test case 2
        Element<int> e1(10, 6);
        if(e1.get_data()!=10){cout << "Incorrect result from get data. Expected 10 but got : " << e1.get_data() << endl;}

        //Test case 3
        Element<string> e2("string data", 19000);
        if(e2.get_data()!="string data"){cout << "Incorrect result from get data. Expected \"string data\" but got : " << e2.get_data() << endl;}

        //Test case 4
        Element<double> e3(1.89, 100000000);
        if(e3.get_data()!=1.89){cout << "Incorrect result from get data. Expected 1.89 but got : " << e2.get_data() << endl;}

    } catch(exception& e) {
        cerr << "Error getting data from element : " << e.what() << endl;
    }
}

void test_insert() { 
    try { 
        //Test case 1
        HashTable<int> empty_ht(0); 
        empty_ht.insert(10, 6);
        string ht_str = empty_ht.to_string();
        if(empty_ht.to_string()!="") {
            cout << "Incorrect result of inserting into table. Expected and empty string But got\n\n" << empty_ht.to_string() << endl;
        }  
    
        //Test case 2
        HashTable<int> ht(5); 
        ht.insert(10, 6);
        if(ht.to_string()!="0: \n1: (10,6) \n2: \n3: \n4: \n") {
            cout << "Incorrect result of inserting into table. Expected\n\n0: \n1: (10,6) \n2: \n3: \n4: \n\nBut got\n\n" << ht.to_string() << endl;
        } 

        //Test case 3
        ht.insert(1, 21);  
        if(ht.to_string()!="0: \n1: (1,21) (10,6) \n2: \n3: \n4: \n") {
            cout << "Incorrect result of inserting into table. Expected\n\n0: \n1: (1,21) (10,6) \n2: \n3: \n4: \n\nBut got \n\n" << ht.to_string() << endl;
        }

        //Test case 4
        ht.insert(6,7);
        if(ht.to_string()!="0: \n1: (1,21) (10,6) \n2: (6,7) \n3: \n4: \n") {
            cout << "Incorrect result of inserting into table. Expected\n\n0: \n1: (1,21) (10,6) \n2: (6,7) \n3: \n4: \nBut got \n\n" << ht.to_string() << endl;
        }

        //Test case 5
        ht.insert(10,5);
        ht.insert(20,8);
        ht.insert(30,9);
        ht.insert(40,10);
        if(ht.to_string()!="0: (40,10) (10,5) \n1: (1,21) (10,6) \n2: (6,7) \n3: (20,8) \n4: (30,9) \n") {
            cout << "Incorrect result of inserting into table. Expected\n\n0: (40,10) (10,5) \n1: (1,21) (10,6) \n2: (6,7) \n3: (20,8) \n4: (30,9) \nBut got \n\n" << ht.to_string() << endl;
        }

        //Test case 6
        ht.insert(10,5);
        if(ht.to_string()!="0: (40,10) (10,5) \n1: (1,21) (10,6) \n2: (6,7) \n3: (20,8) \n4: (30,9) \n") {
            cout << "Incorrect result of inserting into table. Expected\n\n0: (40,10) (10,5) \n1: (1,21) (10,6) \n2: (6,7) \n3: (20,8) \n4: (30,9) \nBut got \n\n" << ht.to_string() << endl;
        }

        //Test case 7
        HashTable<char> ht_c(3);
        ht_c.insert('a', 1);
        ht_c.insert('b', 2);
        ht_c.insert('c', 3);
        ht_c.insert('d', 4);
        if(ht_c.to_string()!="0: (c,3) \n1: (d,4) (a,1) \n2: (b,2) \n") {
            cout << "Incorrect result of inserting into table. Expected\n\n0: (c,3) \n1: (d,4) (a,1) \n2: (b,2) \nBut got \n\n" << ht_c.to_string() << endl;
        }

        //Test case 8 
        HashTable<string> ht_s(4);
        ht_s.insert("CS111", 5);
        ht_s.insert("CS119", 5);
        if(ht_s.to_string()!="0: \n1: (CS111,5) \n2: \n3: \n") {
            cout << "Incorrect result of inserting into table. Expected\n\n0: \n1: (CS111,5) \n2: \n3: \nBut got \n\n" << ht_s.to_string() << endl;
        }

        //Test case 9 
        ht_s.insert("CS271", 9);
        ht_s.insert("CS181", 13);
        ht_s.insert("CS234", 17);
        if(ht_s.to_string()!="0: \n1: (CS234,17) (CS181,13) (CS271,9) (CS111,5) \n2: \n3: \n") {
            cout << "Incorrect result of inserting into table. Expected\n\n0: \n1: (CS234,17) (CS181,13) (CS271,9) (CS111,5)\n2: \n3: \nBut got \n\n" << ht_s.to_string() << endl;
        }

    } catch(exception& e) { 
        cerr << "Error inserting into non-empty table : " << e.what() << endl;
    }
}

void test_remove() {
    try {
        //Test case 1
        HashTable<int> empty_ht(0);
        empty_ht.remove(6);
        if(empty_ht.to_string()!="") {
            cout << "Incorrect result of removing from empty table. Expected and empty string But got\n\n" << empty_ht.to_string() << endl;
        }
    } catch(exception& e) {
        cout << "Error caused by trying to remove from empty table : " << e.what() << endl;
    }
    try {
        //Test case 2
        HashTable<int> ht(5);
        ht.insert(10, 6);
        ht.remove(5);
        if(ht.to_string()!="0: \n1: (10,6) \n2: \n3: \n4: \n") {
            cout << "Incorrect result of removing non-member from table. Expected\n\n0: \n1: (10,6) \n2: \n3: \n4: \n\nBut got\n\n" << ht.to_string() << endl;
        }

        //Test case 3
        ht.remove(6);
        if(ht.to_string()!="0: \n1: \n2: \n3: \n4: \n") {
            cout << "Incorrect result removing member from table. Expected\n\n0: \n1: \n2: \n3: \n4: \n\nBut got\n\n" << ht.to_string() << endl;
        }

        //Test case 4
        ht.remove(6);
        if(ht.to_string()!="0: \n1: \n2: \n3: \n4: \n") {
            cout << "Incorrect result removing member from table. Expected\n\n0: \n1: \n2: \n3: \n4: \n\nBut got\n\n" << ht.to_string() << endl;
        }

        //Test case 5
        ht.insert(10,5);
        ht.insert(20,8);
        ht.insert(30,9);
        ht.insert(40,20);
        ht.remove(10);
        ht.remove(5);
        ht.remove(9);
        ht.insert(10,10);
        if(ht.to_string()!="0: (10,10) (40,20) \n1: \n2: \n3: (20,8) \n4: \n") {
            cout << "Incorrect result removing member from table. Expected\n\n0: (10,10) (40,20) \n1: \n2: \n3: (20,8) \n4: \n\nBut got\n\n" << ht.to_string() << endl;
        }

        //Test case 6
        HashTable<float> ht_f(4);
        ht_f.insert(0.1, 100);
        ht_f.insert(0.2, 200);
        ht_f.insert(0.3, 44);
        ht_f.insert(0.4, 9999);
        ht_f.remove(9999);
        ht_f.remove(100);
        if(ht_f.to_string()!="0: (0.3,44) (0.2,200) \n1: \n2: \n3: \n") {
            cout << "Incorrect result removing member from table. Expected\n\n0: (0.3,44) (0.2,200) \n1: \n2: \n3: \nBut got\n\n" << ht.to_string() << endl;
        }

        //Test case 7 
        ht_f.remove(12345678);
        if(ht_f.to_string()!="0: (0.3,44) (0.2,200) \n1: \n2: \n3: \n") {
            cout << "Incorrect result removing member from table. Expected\n\n0: (0.3,44) (0.2,200) \n1: \n2: \n3: \nBut got\n\n" << ht.to_string() << endl;
        }

        //Test case 8
        HashTable<char> ht_c(3);
        ht_c.insert('R', 23);
        ht_c.insert('A', 56);
        ht_c.insert('B', 78);
        ht_c.insert('B', 32);
        ht_c.insert('I', 65);
        ht_c.insert('T', 87);
        ht_c.remove(23);
        ht_c.remove(87);
        if(ht_c.to_string()!="0: (B,78) \n1: \n2: (I,65) (B,32) (A,56) \n") {
            cout << "Incorrect result removing member from table. Expected\n\n0: (B,78) \n1: \n2: (I,65) (B,32) (A,56) \nBut got\n\n" << ht_c.to_string() << endl;
        }

        //Test case 9 
        ht_c.remove(56);
        ht_c.remove(78);
        ht_c.remove(32);
        ht_c.remove(65);
        if(ht_c.to_string()!="0: \n1: \n2: \n") {
            cout << "Incorrect result removing member from table. Expected 0: \n1: \n2: \nBut got\n\n" << ht_c.to_string() << endl;
        }

    } catch(exception& e) {
        cerr << "Error removing member from table : " << e.what() << endl;
    }
}

void test_member() {
    try {
        //Test case 1
        HashTable<int> empty_ht(0);
        if(empty_ht.member(10, 6)) {cout << "Incorrect membership in empty table" << endl;}

        //Test case 2
        HashTable<int> ht(5);
        ht.insert(10, 6);
        if(ht.member(11, 6)){cout << "Incorrect membership in table" << endl;}

        //Test case 3
        if(!ht.member(10, 6)){cout << "Incorrect non-membership in table" << endl;}

        //Test case 4
        if(ht.member(6, 10)){cout << "Incorrect membership in table" << endl;}

        //Test case 5 
        HashTable<string> ht_s(7);
        ht_s.insert("James", 123);
        ht_s.insert("John", 456);
        ht_s.insert("Casey", 789);
        ht_s.insert("Tyler", 124);
        ht_s.insert("George", 457);
        if(ht_s.member("Julie", 777)){cout << "Incorrect membership in table" << endl;}
        if(ht_s.member("James",321)){cout << "Incorrect membership in table" << endl;}
        if(!ht_s.member("George", 457)){cout << "Incorrect non-membership in table" << endl;}
        if(!ht_s.member("Casey", 789)){cout << "Incorrect non-membership in table" << endl;}

        //Test case 6
        HashTable<long double> ht_ld(1);
        ht_ld.insert(399.123445, 0);
        if(ht_ld.member(399.123445, 2)){cout << "Incorrect membership in table" << endl;}
        if(!ht_ld.member(399.123445, 0)){cout << "Incorrect non-membership in table" << endl;}

    }catch(exception& e) {
        cerr << "Error determining membership from table : " << e.what() << endl;
    }    

}
 
int main()
{
    test_get_key();
    test_get_data();
    test_insert();
    test_member();
    test_remove();

    cout << "Testing completed" << endl;

    return 0; 
}         