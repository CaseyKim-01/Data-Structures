# include <iostream>
# include <fstream>
# include <string>
# include <vector>
# include "hash_table.cpp"
# include "hash_table.h"

using namespace std;

int calculate_hashed_value_msb(int k, int size) {
    int p = log2(size);
    int num_of_bits = floor(log2(k)) + 1;
    return k >> (num_of_bits - p);
}

int calculate_hashed_value_cormen(int k, int size) {
    return floor(size * fmod(k * ((sqrt(5)-1)*0.5),1.0));
}

int main() {
    vector<vector<string>> data;
    vector<string> each_row;
    string line, word;
 
    fstream file ("experimental_data.csv", ios::in);
    if(file.is_open())
    {
        while(getline(file, line))
        {
            stringstream str(line);
 
            while(getline(str, word, ','))
                each_row.push_back(word);
            
            data.push_back(each_row);
            each_row.clear();
        }
    }
    else
        cout<<"Could not open the file\n";

    ofstream result_file;
    result_file.open("result1.csv");
    result_file << "key,hashed_value\n";

    ofstream result_file2;
    result_file2.open("result2.csv");
    result_file2 << "key,hashed_value\n";

    int num_slots = 1024;

    for (int i = 1; i < data.size(); i ++) {
        int key = std::stoll(data[i][0]);
        result_file << key << ",";
        result_file << calculate_hashed_value_msb(key, num_slots) << "\n";
        result_file2 << key << ",";
        result_file2 << calculate_hashed_value_cormen(key, num_slots) << "\n";
    }

    return 0;
}

