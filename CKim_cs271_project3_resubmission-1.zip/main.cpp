# include <iostream>
# include <fstream>
# include <string>

# include "usecase.cpp"

using namespace std;

int main()
{
    string username, password;

    string filename = "logins.csv";
    HashTable<string>* ht = create_table<string>(filename, 30);

    cout << "Enter username: ";
    cin >> username;

    cout << "Enter password: ";
    cin >> password;
    cout << "\n";
    
    if (login(ht, username, password))
        cout<<"Login successful\n";
    else
        cout<<"Login failed\n";

    delete ht;

    return 0;
}