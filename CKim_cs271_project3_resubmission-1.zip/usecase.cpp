# include <iostream> 
# include <fstream>
# include <string> 
# include <sstream> 
# include <vector>

# include "hash_table.cpp"

using namespace std;

/**
 * Creates a hash table from a provided csv file ('fname') of size 'm'.
 * Each key is -1, with the data being the username. Each login info is stored 
 * at ht[h(password)].
 *  
 * Precondition: A valid CSV file exists at 'fname'.
 * Postcondition: A hash table that stores each login info at ht[h(password)] is created
 *                and returned.
 */
template <typename T>
HashTable<T>* create_table(string fname, int m)
{
    HashTable<T>* ht = new HashTable<T>(m);
    // key --> -1
    // data --> username

    // CSV File Reading
    vector<vector<string>> info;
    vector<string> each_row;
    string line, word;
 
    fstream file (fname, ios::in);
    if(file.is_open())
    {
        while(getline(file, line))
        {
            stringstream str(line);
 
            while(getline(str, word, ','))
                each_row.push_back(word);
            
            info.push_back(each_row);
            each_row.clear();
        }
    }
    else
        cout<<"Could not open the file\n";


    for (int i = 0; i < info.size(); i++)
    {
        long long int pw = std::stoll(info[i][1], nullptr, 10);
        ht->insert(info[i][0], pw); // pass in username and password to 
                                    // insert(T data, long long int key)
                                    // and store the data at ht[h(password)]
    }

    return ht;
}

/**
 * Takes in a username and password combination and checks if the username and 
 * password matches.
 *
 * Preconditions: 'ht' is a hash table that stores each username at ht[h(password)],
 *               'username' is a string,
 *               'password' is a string representation of a long long int
 * 
 * Postcondition: returns true if the given username exists at ht[h(password)],
 *                and false otherwise.
 */ 
template<typename T> 
bool login(HashTable<T>* ht, T username, string password) 
{
    long long int pw;
    try {
        pw = std::stoll(password, nullptr, 10);
    }
    catch (std::invalid_argument) {
        return false;
    }
    
    return ht->member(username, pw); 
}

