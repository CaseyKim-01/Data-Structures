# include "hash_table.h"

template<typename T> 
HashTable<T>::HashTable(int num_slots)
{
    // Assign the size of the hash table 
    size = num_slots;
    // Allocate 'num_slots' number of lists to the member 'table'
    table = new list<Element<T>>[num_slots];
    //Assign the type of hash function
} 

template<typename T> 
HashTable<T>::~HashTable()
{
    delete[] table;
}

template<typename T>
unsigned int HashTable<T>::get_hash(long long int k)
{
    // Calculate the hash and return its value 
    return k % size; 
}

template<typename T> 
bool HashTable<T>::contains(long long int k)
{
    // Hash table with 0 slots
    if (size == 0)
        return false;
    // Calculate the hash value of the input key and 
    // iterate through the list at table[hashed] to search the element 
    unsigned int hashed = get_hash(k);
    // Validate h(k) as an index
    if (hashed < 0 || hashed >= size)
        return false;
    for (Element<T> e : table[hashed])
    {
        if (e.get_key() == k)
            return true;
    }
    return false;
}

template<typename T>
bool HashTable<T>::member(T d, int k)
{
    // Hash table with 0 slots
    if (size == 0)
        return false;
    // Calculate the hash value of the input key and 
    // iterate through the list at table[hashed] to search the element 
    int hashed = get_hash(k);
    for (Element<T> e : table[hashed])
    {
        if (e.get_data() == d && e.get_key() == k)
            return true;
    }
    return false; 
}

// for usecase
template<typename T>
bool HashTable<T>::member(T d, long long int k)
{
    // Hash table with 0 slots
    if (size == 0)
        return false;
    // Calculate the hash value of the input key and 
    // iterate through the list at table[hashed] to search the element 
    long long int hashed = get_hash(k);
    for (Element<T> e : table[hashed])
    {
        if (e.get_data() == d)
            return true;
    }
    return false; 
}

template<typename T>
void HashTable<T>::insert(T data, int key)
{
    // Hash table with 0 slots
    if (size == 0)
        return;
    // If the input key already exists in the table
    if (contains(key))
        return;
    int hashed = get_hash(key);
    // Validate h(k) as an index
    if (hashed < 0 || hashed >= size)
        return;
    // Save the input data and key into a new Element object 
    // and insert the element at the head of the corresponding list
    Element<T> e(data, key);
    table[hashed].push_front(e);
}

// for usecase
template<typename T>
void HashTable<T>::insert(T data, long long int key)
{
    // Hash table with 0 slots
    if (size == 0)
        return;
    // If the input key already exists in the table
    if (contains(key))
        return;
    long long int hashed = get_hash(key);
    // Validate h(k) as an index
    if (hashed < 0 || hashed >= size)
        return;
    // Save the input data and key into a new Element object 
    // and insert the element at the head of the corresponding list
    Element<T> e(data, -1);
    table[hashed].push_front(e);
}

template<typename T>
void HashTable<T>::remove(long long int k) 
{
    // Hash table with 0 slots
    if (size == 0)
        return;
    // If the input key does not exist in the table
    if (!contains(k))
        return;
    // Calculate the hash value of the input element and 
    // delete the element from the corresponding list, 
    // which will remove the element from the entire hash table
    unsigned int hashed = get_hash(k);
    table[hashed].remove_if([k](Element<T> element){ return element.get_key() == k; }); 
}

template<typename T>
string HashTable<T>::to_string() 
{
    // Hash table with 0 slots 
    if (size == 0)
        return "";
    stringstream ss;
    // Iterate through each slot and insert the key and the data of each element in the slot
    // into the string stream 
    for (int i = 0; i < size; i++)
    {
        ss << i << ": ";
        for (Element<T> e : table[i]) {
            ss << '(' << e.get_data() << ',' << e.get_key() << ')';
            ss << ' ';
        }
        ss << '\n';
    }
    return ss.str();
}

